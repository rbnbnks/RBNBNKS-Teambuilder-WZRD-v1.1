
function textStudioShade(hex, percent) {
  const v = hex.replace('#', '');
  const num = parseInt(v, 16);
  let r = (num >> 16) + Math.round(255 * (percent / 100));
  let g = ((num >> 8) & 0xff) + Math.round(255 * (percent / 100));
  let b = (num & 0xff) + Math.round(255 * (percent / 100));
  r = Math.max(0, Math.min(255, r));
  g = Math.max(0, Math.min(255, g));
  b = Math.max(0, Math.min(255, b));
  return `rgb(${r},${g},${b})`;
}

let ACTIVE_KERNING = 'font';
let ACTIVE_ARCH_TYPE = 'parabola';
let ACTIVE_LETTER_EDIT = null;
let ACTIVE_WARP = {on:false,type:'bulge',strength:0,cycles:1.5};
let ACTIVE_IMPERFECTION = {on:false,baseline:0,rotation:0,scale:0,tracking:0,seed:57};
let EFFECT_LAYER_ORDER = ['texture','pattern','inset','bevel','finish','overlay'];

function opticalPairAdjust(ctx, a, b) {
  if (ACTIVE_KERNING !== 'optical') return 0;
  const pair=(a+b).toUpperCase();
  const strong=['AV','VA','AW','WA','AY','YA','AT','TA','LT','TY','To'.toUpperCase(),'FA','PA'];
  const medium=['LA','LV','LY','UT','VT','WT','XA','KA','RA'];
  const fs=parseFloat(ctx.font)||100;
  if (strong.includes(pair)) return -fs*.09;
  if (medium.includes(pair)) return -fs*.05;
  return 0;
}

function glyphNoise(index, channel, seed){
  return seededNoise(index + 1, channel + 11, seed || 57) * 2 - 1;
}

function trackingNoise(index, ctx){
  if(!ACTIVE_IMPERFECTION.on || !ACTIVE_IMPERFECTION.tracking) return 0;
  return glyphNoise(index, 5, ACTIVE_IMPERFECTION.seed) * ACTIVE_IMPERFECTION.tracking;
}

function measureSpacedText(ctx, text, letterSpacing) {
  if (!text) return 0;
  let width = 0;
  for (let i = 0; i < text.length; i++) {
    width += ctx.measureText(text[i]).width;
    if (i < text.length - 1) width += letterSpacing + opticalPairAdjust(ctx,text[i],text[i+1]) + trackingNoise(i,ctx);
  }
  return width;
}

function warpGlyphData(u, fontSize){
  if(!ACTIVE_WARP.on) return {y:0,rot:0,sx:1,sy:1};
  const k=ACTIVE_WARP.strength/100, a=Math.abs(k), px=fontSize*.58*k;
  if(ACTIVE_WARP.type==='squeeze') return {y:0,rot:0,sx:Math.max(.35,1-a*Math.abs(u)*.55),sy:1};
  if(ACTIVE_WARP.type==='bulge') {const q=(1-u*u); return {y:0,rot:0,sx:1+a*q*.25,sy:1+k*q*.42};}
  if(ACTIVE_WARP.type==='wave'){const cyc=ACTIVE_WARP.cycles||1.5,ang=(u+1)*Math.PI*cyc;return {y:Math.sin(ang)*px,rot:Math.cos(ang)*k*.16,sx:1,sy:1};}
  if(ACTIVE_WARP.type==='pennant'){const q=(u+1)/2;return {y:-px*q*.18,rot:0,sx:Math.max(.45,1-k*q*.38),sy:Math.max(.45,1-k*q*.62)};}
  if(ACTIVE_WARP.type==='trapezoid'){return {y:0,rot:0,sx:Math.max(.45,1+k*u*.35),sy:Math.max(.55,1+k*u*.28)};}
  if(ACTIVE_WARP.type==='rise'){return {y:-px*u,rot:-k*.08,sx:1,sy:1};}
  if(ACTIVE_WARP.type==='radial'){return {y:-px*(1-Math.abs(u))*.55,rot:u*k*.38,sx:1,sy:1+a*(1-Math.abs(u))*.18};}
  return {y:0,rot:0,sx:1,sy:1};
}

function drawSpacedText(ctx, text, x, y, letterSpacing, mode, archAmount = 0) {
  const totalWidth = measureSpacedText(ctx, text, letterSpacing);
  let cursor = x - totalWidth / 2;
  const halfWidth = Math.max(totalWidth / 2, 1);
  const fontSize=parseFloat(ctx.font)||100;
  ctx.textAlign='center';
  const baseFill=ctx.fillStyle, baseAlpha=ctx.globalAlpha;
  for(let i=0;i<text.length;i++){
    const ch=text[i], chWidth=ctx.measureText(ch).width;
    const centerX=cursor+chWidth/2;
    const u=Math.max(-1,Math.min(1,(centerX-x)/halfWidth));
    const [curveY,slope]=archAmount?curveData(u,archAmount,halfWidth,ACTIVE_ARCH_TYPE):[0,0];
    const edit=ACTIVE_LETTER_EDIT && ACTIVE_LETTER_EDIT.on && ACTIVE_LETTER_EDIT.index===i ? ACTIVE_LETTER_EDIT : null;
    const warp=warpGlyphData(u,fontSize);
    let jy=0,jr=0,js=1;
    if(ACTIVE_IMPERFECTION.on){
      jy=glyphNoise(i,1,ACTIVE_IMPERFECTION.seed)*fontSize*(ACTIVE_IMPERFECTION.baseline/100);
      jr=glyphNoise(i,2,ACTIVE_IMPERFECTION.seed)*(ACTIVE_IMPERFECTION.rotation*Math.PI/180);
      js=1+glyphNoise(i,3,ACTIVE_IMPERFECTION.seed)*(ACTIVE_IMPERFECTION.scale/100);
    }
    ctx.save();
    ctx.translate(centerX+(edit?edit.x:0),y+curveY+warp.y+jy+(edit?edit.y:0));
    ctx.rotate(Math.atan(slope)+warp.rot+jr+(edit?edit.rotate:0));
    ctx.scale(warp.sx*js*(edit?edit.scale:1),warp.sy*js*(edit?edit.scale:1));
    if(mode==='fill' && edit && edit.colorOn) ctx.fillStyle=edit.color;
    if(mode==='stroke') ctx.strokeText(ch,0,0); else ctx.fillText(ch,0,0);
    ctx.restore();
    ctx.fillStyle=baseFill; ctx.globalAlpha=baseAlpha;
    cursor += chWidth + (i<text.length-1 ? letterSpacing+opticalPairAdjust(ctx,text[i],text[i+1])+trackingNoise(i,ctx) : 0);
  }
  ctx.textAlign='center';
}

function fitFontSize(ctx, lines, fontFamily, maxWidth, maxHeight, letterSpacing, scaleX, scaleY, lineSpacing, archStrength) {
  let size = Math.floor(maxHeight / Math.max(1, lines.length));
  const minSize = 8;
  while (size > minSize) {
    ctx.font = `${size}px ${canvasFontFamily(fontFamily)}`;
    const widest = Math.max(...lines.map(l => measureSpacedText(ctx, l || ' ', letterSpacing) * scaleX));
    const archHeight = size * Math.abs(archStrength) / 100 * 1.15;
    const totalHeight = (size * lines.length * lineSpacing + archHeight) * scaleY;
    if (widest <= maxWidth && totalHeight <= maxHeight) break;
    size -= 2;
  }
  return size;
}

function hexToRgba(hex, alpha) {
  const v = hex.replace('#', '');
  const num = parseInt(v, 16);
  const r = num >> 16;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}

function colorAlpha(hex, alpha) {
  const v = hex.replace('#',''); const n=parseInt(v,16);
  return `rgba(${n>>16},${(n>>8)&255},${n&255},${alpha})`;
}

function seededNoise(x, y, seed = 1) {
  const n = Math.sin(x * 12.9898 + y * 78.233 + seed * 37.719) * 43758.5453;
  return n - Math.floor(n);
}

function applyTextureOverlay(mainCtx, w, h, texture, strength, textureScale, textureColor, drawMask) {
  if (!texture || texture === 'none' || strength <= 0) return;
  const alpha=Math.max(0,Math.min(1,strength/100)), sc=Math.max(.25,textureScale/100);
  const mask=document.createElement('canvas'); mask.width=w; mask.height=h; const m=mask.getContext('2d'); drawMask(m);
  const layer=document.createElement('canvas'); layer.width=w; layer.height=h; const t=layer.getContext('2d');
  const col=(a)=>colorAlpha(textureColor,a*alpha), dark=(a)=>colorAlpha(textStudioShadeHex(textureColor,-42),a*alpha), light=(a)=>colorAlpha(textStudioShadeHex(textureColor,36),a*alpha);
  const line=(x1,y1,x2,y2,style,width=1)=>{t.strokeStyle=style;t.lineWidth=width;t.beginPath();t.moveTo(x1,y1);t.lineTo(x2,y2);t.stroke();};
  if(texture==='twill'){const step=Math.max(4,8*sc);for(let x=-h;x<w+h;x+=step){line(x,0,x+h,h,light(.8),Math.max(1,1.6*sc));line(x+step*.42,0,x+h+step*.42,h,dark(.65),Math.max(1,1.3*sc));}}
  else if(texture==='screen'){const step=Math.max(3,5*sc),r=Math.max(.7,1.15*sc);for(let y=0;y<h+step;y+=step)for(let x=0;x<w+step;x+=step){t.fillStyle=col(.75);t.beginPath();t.arc(x+((Math.floor(y/step)%2)*step/2),y,r,0,Math.PI*2);t.fill();}}
  else if(texture==='endzone'){
    const unit=Math.max(2.2,5.5*sc), density=Math.max(.12,Math.min(1,alpha));

    // Uneven sprayed paint deposit.
    for(let y=-unit;y<h+unit;y+=unit*1.12){
      for(let x=-unit;x<w+unit;x+=unit*1.12){
        const n=seededNoise(Math.floor(x/unit),Math.floor(y/unit),191);
        if(n>.13){
          t.globalAlpha=.38+density*.55;
          t.fillStyle=n>.72?light(.7):col(.82);
          const rw=unit*(.65+n*.85),rh=unit*(.38+n*.55);
          t.fillRect(x+(n-.5)*unit*.55,y+(seededNoise(x,y,193)-.5)*unit*.65,rw,rh);
        }
      }
    }

    // Horizontal/diagonal spray pass banding.
    t.globalAlpha=.12+density*.18;
    for(let y=0;y<h;y+=Math.max(7,unit*3.1)){
      line(-20,y,w+20,y+(seededNoise(y,1,197)-.5)*unit*1.4,light(.35),Math.max(.7,unit*.18));
    }

    // Grass blades and turf gaps interrupt the paint.
    t.globalCompositeOperation='destination-out';
    const bladeCount=Math.floor((w*h)/Math.max(85,620/(density+.08)));
    for(let i=0;i<bladeCount;i++){
      const x=seededNoise(i,2,199)*w,y=seededNoise(i,3,211)*h;
      const len=(1.1+seededNoise(i,4,223)*5.2)*sc;
      const lean=(seededNoise(i,5,227)-.5)*1.05;
      t.globalAlpha=.18+density*.56;
      t.strokeStyle='#000';
      t.lineWidth=Math.max(.4,.75*sc);
      t.beginPath();t.moveTo(x,y);t.lineTo(x+Math.sin(lean)*len,y-len);t.stroke();
      if(i%5===0){
        t.globalAlpha=.12+density*.32;
        t.fillStyle='#000';
        t.beginPath();t.arc(x,y,Math.max(.3,(.4+seededNoise(i,6,229)*1.2)*sc),0,Math.PI*2);t.fill();
      }
    }

    // Fine paint droplets sit back on top of the broken field texture.
    t.globalCompositeOperation='source-over';
    t.globalAlpha=.16+density*.28;
    const flecks=Math.floor((w*h)/Math.max(150,920/(density+.12)));
    for(let i=0;i<flecks;i++){
      const x=seededNoise(i,7,233)*w,y=seededNoise(i,8,239)*h;
      const r=(.25+seededNoise(i,9,241)*1.1)*sc;
      t.fillStyle=i%3===0?light(.62):col(.58);
      t.beginPath();t.arc(x,y,r,0,Math.PI*2);t.fill();
    }
    t.globalAlpha=1;
  }
  else if(texture==='mesh'){const step=Math.max(7,12*sc),r=Math.max(1.5,2.7*sc);for(let y=0;y<h+step;y+=step)for(let x=0;x<w+step;x+=step){const xx=x+((Math.floor(y/step)%2)*step/2);t.fillStyle=dark(.8);t.beginPath();t.arc(xx,y,r,0,Math.PI*2);t.fill();t.strokeStyle=light(.5);t.lineWidth=Math.max(.7,.9*sc);t.stroke();}}
  else if(texture==='dazzle'){const g=t.createLinearGradient(0,0,w,h);g.addColorStop(0,dark(.35));g.addColorStop(.28,col(.35));g.addColorStop(.43,light(.9));g.addColorStop(.6,dark(.45));g.addColorStop(.78,light(.75));g.addColorStop(1,dark(.25));t.fillStyle=g;t.fillRect(0,0,w,h);}
  else if(texture==='heather'){const count=Math.floor((w*h)/(90*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,3)*w,y=seededNoise(i,2,5)*h,len=(2+seededNoise(i,3,7)*9)*sc;line(x,y,x+len,y+len*.18,seededNoise(i,4,9)>.5?light(.7):dark(.55),Math.max(.7,1.1*sc));}}
  else if(texture==='distress'){const count=Math.floor((w*h)/(65*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,11)*w,y=seededNoise(i,2,13)*h,rw=(1+seededNoise(i,3,17)*11)*sc,rh=(1+seededNoise(i,4,19)*4)*sc;t.fillStyle=dark(.55+seededNoise(i,5,23)*.4);t.fillRect(x,y,rw,rh);}}
  else if(texture==='topo'){t.strokeStyle=col(.95);t.lineWidth=Math.max(1,1.5*sc);const gap=Math.max(10,18*sc);for(let base=-40;base<h+40;base+=gap){t.beginPath();for(let x=0;x<=w;x+=Math.max(4,8*sc)){const y=base+Math.sin(x/(38*sc))*5*sc+Math.sin(x/(91*sc))*7*sc;if(x===0)t.moveTo(x,y);else t.lineTo(x,y);}t.stroke();}}
  else if(texture==='weave'){const step=Math.max(4,7*sc);for(let x=-h;x<w+h;x+=step)line(x,0,x+h,h,dark(.65),Math.max(.8,1.2*sc));for(let x=0;x<w+h;x+=step*2)line(x,0,x-h,h,light(.5),Math.max(.8,1.1*sc));}
  else if(texture==='grain'){const count=Math.floor((w*h)/(45*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,29)*w,y=seededNoise(i,2,31)*h,r=(.4+seededNoise(i,3,37)*1.45)*sc;t.fillStyle=seededNoise(i,4,41)>.52?light(.55):dark(.55);t.beginPath();t.arc(x,y,r,0,Math.PI*2);t.fill();}}
  else if(texture==='sublimation'){const band=Math.max(14,28*sc);for(let y=-h;y<h*2;y+=band){t.save();t.translate(w/2,h/2);t.rotate(-Math.PI/9);t.fillStyle=col(.75);t.fillRect(-w*1.5,y-h/2,w*3,band*.42);t.fillStyle=dark(.32);t.fillRect(-w*1.5,y-h/2+band*.42,w*3,band*.16);t.restore();}}
  else if(texture==='carbon'){const cell=Math.max(5,10*sc);for(let y=0;y<h;y+=cell)for(let x=0;x<w;x+=cell){t.fillStyle=((x/cell+y/cell)%2<1)?col(.72):dark(.5);t.fillRect(x,y,cell*.52,cell);t.fillStyle=light(.35);t.fillRect(x+cell*.52,y,cell*.48,cell*.48);}}
  else if(texture==='ripstop'){const step=Math.max(8,18*sc);t.strokeStyle=col(.8);t.lineWidth=Math.max(.8,1.2*sc);for(let x=0;x<w;x+=step){line(x,0,x,h,col(.8),t.lineWidth)}for(let y=0;y<h;y+=step){line(0,y,w,y,col(.8),t.lineWidth)}}
  else if(texture==='honeycomb'){const r=Math.max(4,9*sc),dx=r*1.73,dy=r*1.5;t.strokeStyle=col(.9);t.lineWidth=Math.max(1,1.4*sc);for(let row=0,y=0;y<h+r;row++,y+=dy)for(let x=(row%2)*dx/2;x<w+r;x+=dx){t.beginPath();for(let k=0;k<6;k++){const a=Math.PI/3*k,xx=x+r*Math.cos(a),yy=y+r*Math.sin(a);k?t.lineTo(xx,yy):t.moveTo(xx,yy)}t.closePath();t.stroke();}}
  else if(texture==='checker'){const q=Math.max(6,18*sc);for(let y=0;y<h;y+=q)for(let x=0;x<w;x+=q){if(((x/q|0)+(y/q|0))%2===0){t.fillStyle=col(.8);t.fillRect(x,y,q,q);}}}
  else if(texture==='pinstripe'){const step=Math.max(7,16*sc);for(let x=0;x<w;x+=step)line(x,0,x,h,col(.95),Math.max(1,1.5*sc));}
  else if(texture==='brushed'){const count=Math.floor(h/(2*sc));for(let i=0;i<count;i++){const y=seededNoise(i,2,77)*h, x=seededNoise(i,3,79)*w*.25,len=w*(.2+seededNoise(i,4,83)*.8);line(x,y,Math.min(w,x+len),y,seededNoise(i,5,89)>.5?light(.5):dark(.45),Math.max(.5,.8*sc));}}
  else if(texture==='diamond'){const step=Math.max(8,18*sc);for(let x=-h;x<w+h;x+=step){line(x,0,x+h,h,col(.65),1.3*sc);line(x+h,0,x,h,col(.65),1.3*sc);}}
  else if(texture==='digitalcamo'){const q=Math.max(5,12*sc);for(let y=0;y<h;y+=q)for(let x=0;x<w;x+=q){const n=seededNoise(x/q,y/q,101);if(n>.48){t.fillStyle=n>.75?col(.85):dark(.6);t.fillRect(x,y,q*(1+(n>.82)),q);}}}
  else if(texture==='camo'){const count=Math.floor((w*h)/(1100*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,103)*w,y=seededNoise(i,2,107)*h,rx=(12+seededNoise(i,3,109)*35)*sc,ry=(7+seededNoise(i,4,113)*20)*sc;t.fillStyle=i%2?col(.72):dark(.55);t.beginPath();t.ellipse(x,y,rx,ry,seededNoise(i,5,127)*Math.PI,0,Math.PI*2);t.fill();}}
  else if(texture==='splatter'){const count=Math.floor((w*h)/(220*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,131)*w,y=seededNoise(i,2,137)*h,r=(1+seededNoise(i,3,139)*6)*sc;t.fillStyle=col(.55+seededNoise(i,4,149)*.4);t.beginPath();t.arc(x,y,r,0,Math.PI*2);t.fill();}}
  else if(texture==='wave'){const gap=Math.max(10,22*sc);t.strokeStyle=col(.9);t.lineWidth=Math.max(1,1.5*sc);for(let base=0;base<h+gap;base+=gap){t.beginPath();for(let x=0;x<=w;x+=5*sc){const y=base+Math.sin(x/(24*sc))*6*sc;x?t.lineTo(x,y):t.moveTo(x,y)}t.stroke();}}
  else if(texture==='lightning'){const step=Math.max(35,80*sc);t.strokeStyle=col(.9);t.lineWidth=Math.max(2,3*sc);for(let x=-step;x<w+step;x+=step){t.beginPath();t.moveTo(x,0);t.lineTo(x+step*.3,h*.35);t.lineTo(x+step*.05,h*.35);t.lineTo(x+step*.55,h);t.stroke();}}
  else if(texture==='stars'){const step=Math.max(18,38*sc),r=Math.max(2,5*sc);for(let y=0;y<h+step;y+=step)for(let x=0;x<w+step;x+=step){const xx=x+((y/step|0)%2)*step/2;t.fillStyle=col(.9);t.beginPath();for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,rr=k%2? r*.42:r,px=xx+Math.cos(a)*rr,py=y+Math.sin(a)*rr;k?t.lineTo(px,py):t.moveTo(px,py)}t.closePath();t.fill();}}
  else if(texture==='halftone'){const step=Math.max(5,10*sc);for(let y=0;y<h;y+=step)for(let x=0;x<w;x+=step){const prog=x/w,r=Math.max(.4,(1-prog)*3.4*sc);t.fillStyle=col(.85);t.beginPath();t.arc(x,y,r,0,Math.PI*2);t.fill();}}
  else if(texture==='crackle'){const count=Math.floor((w*h)/(700*sc*sc));for(let i=0;i<count;i++){let x=seededNoise(i,1,151)*w,y=seededNoise(i,2,157)*h;t.strokeStyle=col(.9);t.lineWidth=Math.max(.8,1.2*sc);t.beginPath();t.moveTo(x,y);for(let k=0;k<5;k++){x+=(seededNoise(i,k,163)-.5)*28*sc;y+=(8+seededNoise(i,k,167)*18)*sc;t.lineTo(x,y)}t.stroke();}}
  else if(texture==='chenille'){const step=Math.max(3,5*sc);t.lineCap='round';for(let y=0;y<h;y+=step)for(let x=(y/step%2)*step/2;x<w;x+=step){const a=seededNoise(x,y,301)*Math.PI;t.strokeStyle=seededNoise(x,y,303)>.5?light(.8):col(.85);t.lineWidth=Math.max(1.2,2.2*sc);t.beginPath();t.moveTo(x-Math.cos(a)*step*.45,y-Math.sin(a)*step*.45);t.lineTo(x+Math.cos(a)*step*.45,y+Math.sin(a)*step*.45);t.stroke();}}
  else if(texture==='felt'){const count=Math.floor((w*h)/(34*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,307)*w,y=seededNoise(i,2,311)*h,r=(.35+seededNoise(i,3,313)*1.3)*sc;t.fillStyle=i%3?col(.58):light(.46);t.beginPath();t.arc(x,y,r,0,Math.PI*2);t.fill();}}
  else if(texture==='puff'){const g=t.createLinearGradient(0,0,w,h);g.addColorStop(0,light(.82));g.addColorStop(.22,col(.25));g.addColorStop(.72,dark(.24));g.addColorStop(1,dark(.72));t.fillStyle=g;t.fillRect(0,0,w,h);for(let y=5*sc;y<h;y+=7*sc)line(0,y,w,y,light(.18),Math.max(.5,.7*sc));}
  else if(texture==='lasercut'){const step=Math.max(5,9*sc);for(let x=-h;x<w+h;x+=step){line(x,0,x+h,h,light(.48),Math.max(.7,1*sc));line(x+step*.45,0,x+h+step*.45,h,dark(.35),Math.max(.6,.8*sc));}}
  else if(texture==='frayed'){const count=Math.floor((w*h)/(80*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,317)*w,y=seededNoise(i,2,319)*h,len=(2+seededNoise(i,3,323)*12)*sc,ang=seededNoise(i,4,331)*Math.PI;line(x,y,x+Math.cos(ang)*len,y+Math.sin(ang)*len,i%2?light(.6):dark(.5),Math.max(.5,.8*sc));}}
  else if(texture==='rubber'){const g=t.createLinearGradient(0,0,0,h);g.addColorStop(0,light(.48));g.addColorStop(.14,col(.08));g.addColorStop(.82,dark(.12));g.addColorStop(1,dark(.55));t.fillStyle=g;t.fillRect(0,0,w,h);}
  else if(texture==='reflective'){const g=t.createLinearGradient(0,0,w,h);g.addColorStop(0,dark(.25));g.addColorStop(.38,col(.2));g.addColorStop(.49,light(.98));g.addColorStop(.57,col(.35));g.addColorStop(1,dark(.28));t.fillStyle=g;t.fillRect(0,0,w,h);}
  else if(texture==='glitter'){const count=Math.floor((w*h)/(18*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,337)*w,y=seededNoise(i,2,347)*h,r=(.35+seededNoise(i,3,349)*1.8)*sc;t.fillStyle=seededNoise(i,4,353)>.72?light(1):col(.72);t.fillRect(x-r,y-r,r*2,r*2);}}
  else if(texture==='prismatic'){const g=t.createLinearGradient(0,0,w,h);['#ff4d4d','#ffcc33','#5fe38d','#55bfff','#8f6fff','#ff65bf','#ff4d4d'].forEach((c,i)=>g.addColorStop(i/6,colorAlpha(c,.72*alpha)));t.fillStyle=g;t.fillRect(0,0,w,h);for(let x=-h;x<w+h;x+=18*sc)line(x,0,x+h,h,'rgba(255,255,255,.28)',2*sc);}
  else if(texture==='leather'||texture==='football'||texture==='basketball'){const seed=texture==='leather'?359:texture==='football'?367:373,step=Math.max(4,(texture==='basketball'?7:6)*sc);for(let y=0;y<h;y+=step)for(let x=0;x<w;x+=step){const ox=(seededNoise(x,y,seed)-.5)*step*.6,oy=(seededNoise(x,y,seed+2)-.5)*step*.6,r=Math.max(.8,(texture==='basketball'?1.65:1.25)*sc);t.fillStyle=seededNoise(x,y,seed+4)>.5?light(.46):dark(.42);t.beginPath();t.ellipse(x+ox,y+oy,r*1.35,r,0,0,Math.PI*2);t.fill();}}
  else if(texture==='misregister'){t.fillStyle=col(.62);t.fillRect(3*sc,2*sc,w,h);t.globalCompositeOperation='screen';t.fillStyle=dark(.52);t.fillRect(-3*sc,-2*sc,w,h);t.globalCompositeOperation='source-over';}
  else if(texture==='sunfade'){const g=t.createLinearGradient(0,0,w,h);g.addColorStop(0,light(.78));g.addColorStop(.36,col(.36));g.addColorStop(1,dark(.2));t.fillStyle=g;t.fillRect(0,0,w,h);const count=Math.floor((w*h)/(180*sc*sc));for(let i=0;i<count;i++){t.fillStyle=light(.25);t.fillRect(seededNoise(i,1,379)*w,seededNoise(i,2,383)*h,18*sc,2*sc);}}
  else if(texture==='inkbleed'){t.filter=`blur(${Math.max(.7,1.4*sc)}px)`;t.fillStyle=col(.66);t.fillRect(0,0,w,h);t.filter='none';const count=Math.floor((w*h)/(120*sc*sc));for(let i=0;i<count;i++){t.fillStyle=dark(.3);t.beginPath();t.arc(seededNoise(i,1,389)*w,seededNoise(i,2,397)*h,(1+seededNoise(i,3,401)*3)*sc,0,Math.PI*2);t.fill();}}
  else if(texture==='waterbased'){const count=Math.floor((w*h)/(38*sc*sc));for(let i=0;i<count;i++){const x=seededNoise(i,1,409)*w,y=seededNoise(i,2,419)*h;t.globalAlpha=.2+seededNoise(i,3,421)*.35;t.fillStyle=i%2?light(.45):dark(.4);t.fillRect(x,y,(1+seededNoise(i,4,431)*4)*sc,.8*sc);}t.globalAlpha=1;}
  else if(texture==='highdensity'){const g=t.createLinearGradient(0,0,0,h);g.addColorStop(0,light(.55));g.addColorStop(.08,col(.18));g.addColorStop(.9,dark(.14));g.addColorStop(1,dark(.62));t.fillStyle=g;t.fillRect(0,0,w,h);}
  else if(texture==='baseball'){t.fillStyle=light(.28);t.fillRect(0,0,w,h);const gap=Math.max(20,42*sc);for(let y=gap/2;y<h;y+=gap){line(0,y,w,y,col(.72),2*sc);for(let x=0;x<w;x+=8*sc){line(x,y-4*sc,x+4*sc,y+4*sc,dark(.72),1.3*sc);line(x+4*sc,y-4*sc,x+8*sc,y+4*sc,dark(.72),1.3*sc);}}}
  else if(texture==='hockeyknit'){const step=Math.max(4,7*sc);for(let x=0;x<w;x+=step){line(x,0,x,h,light(.5),1.2*sc);line(x+step*.45,0,x+step*.45,h,dark(.38),1*sc);}for(let y=0;y<h;y+=step*1.6)line(0,y,w,y,col(.24),.7*sc);}
  else if(texture==='chainmail'){const r=Math.max(2,4.5*sc),dx=r*1.75,dy=r*1.5;for(let row=0,y=0;y<h+r;row++,y+=dy)for(let x=(row%2)*dx/2;x<w+r;x+=dx){t.strokeStyle=light(.66);t.lineWidth=Math.max(.7,1*sc);t.beginPath();t.arc(x,y,r,0,Math.PI*2);t.stroke();t.fillStyle=dark(.45);t.beginPath();t.arc(x,y,r*.42,0,Math.PI*2);t.fill();}}
  else if(texture==='durene'){const step=Math.max(3,5*sc);for(let x=0;x<w;x+=step){line(x,0,x,h,light(.4),1*sc);line(x+step*.45,0,x+step*.45,h,dark(.35),.8*sc);}for(let y=0;y<h;y+=step*2)line(0,y,w,y,col(.25),.6*sc);}
  else if(texture==='ventilated'){const step=Math.max(9,16*sc),r=Math.max(1.6,3.2*sc);for(let y=0;y<h+step;y+=step)for(let x=(y/step%2)*step/2;x<w+step;x+=step){t.fillStyle=dark(.92);t.beginPath();t.arc(x,y,r,0,Math.PI*2);t.fill();}}
  else if(texture==='microrib'){const step=Math.max(2.5,4*sc);for(let x=0;x<w;x+=step){line(x,0,x,h,light(.48),Math.max(.5,.8*sc));line(x+step*.48,0,x+step*.48,h,dark(.35),Math.max(.45,.65*sc));}}
  else if(texture==='corduroy'){const step=Math.max(5,9*sc);for(let x=0;x<w;x+=step){const g=t.createLinearGradient(x,0,x+step,0);g.addColorStop(0,dark(.5));g.addColorStop(.45,light(.62));g.addColorStop(1,dark(.48));t.fillStyle=g;t.fillRect(x,0,step,h);}}
  else if(texture==='seersucker'){const step=Math.max(8,15*sc);for(let x=0;x<w;x+=step){t.fillStyle=col(.44);t.fillRect(x,0,step*.5,h);for(let y=0;y<h;y+=6*sc)line(x,y,x+step*.5,y+2*sc,light(.35),.8*sc);}}
  t.globalCompositeOperation='destination-in';t.drawImage(mask,0,0);t.globalCompositeOperation='source-over';mainCtx.drawImage(layer,0,0);

  if(texture==='endzone'){
    // Faint paint mist just beyond the letter edge; keeps the center transparent
    // and preserves a crisp readable wordmark silhouette.
    const haze=document.createElement('canvas');haze.width=w;haze.height=h;
    const hc=haze.getContext('2d');
    hc.save();
    hc.filter=`blur(${Math.max(.8,1.35*sc)}px)`;
    hc.globalAlpha=Math.min(.30,.08+alpha*.18);
    hc.drawImage(mask,0,0);
    hc.restore();
    hc.globalCompositeOperation='source-in';
    hc.fillStyle=colorAlpha(textureColor,Math.min(.28,.07+alpha*.18));
    hc.fillRect(0,0,w,h);
    hc.globalCompositeOperation='destination-out';
    hc.drawImage(mask,0,0);
    hc.globalCompositeOperation='source-over';
    mainCtx.drawImage(haze,0,0);
  }
}

function textStudioShadeHex(hex, percent){
  const v=hex.replace('#',''),num=parseInt(v,16);let r=(num>>16)+Math.round(255*percent/100),g=((num>>8)&255)+Math.round(255*percent/100),b=(num&255)+Math.round(255*percent/100);r=Math.max(0,Math.min(255,r));g=Math.max(0,Math.min(255,g));b=Math.max(0,Math.min(255,b));return '#'+[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');
}

function applyMaskedLayer(mainCtx,w,h,drawMask,drawContent){const mask=document.createElement('canvas');mask.width=w;mask.height=h;const m=mask.getContext('2d');drawMask(m);const layer=document.createElement('canvas');layer.width=w;layer.height=h;const l=layer.getContext('2d');drawContent(l);l.globalCompositeOperation='destination-in';l.drawImage(mask,0,0);l.globalCompositeOperation='source-over';mainCtx.drawImage(layer,0,0);}

function applyBevel(mainCtx,w,h,size,strength,drawMask){if(strength<=0)return;const a=strength/100;applyMaskedLayer(mainCtx,w,h,drawMask,l=>{l.globalAlpha=a*.7;l.drawImage(makeMaskCanvas(w,h,drawMask),-size,-size);l.globalCompositeOperation='source-in';l.fillStyle='rgba(255,255,255,.9)';l.fillRect(0,0,w,h);});applyMaskedLayer(mainCtx,w,h,drawMask,l=>{l.globalAlpha=a*.55;l.drawImage(makeMaskCanvas(w,h,drawMask),size,size);l.globalCompositeOperation='source-in';l.fillStyle='rgba(0,0,0,.9)';l.fillRect(0,0,w,h);});}
function makeMaskCanvas(w,h,drawMask){const c=document.createElement('canvas');c.width=w;c.height=h;drawMask(c.getContext('2d'));return c;}

function applyFinishOverlay(mainCtx,w,h,type,strength,drawMask){if(!type||type==='none'||strength<=0)return;const a=strength/100;applyMaskedLayer(mainCtx,w,h,drawMask,l=>{let g;if(type==='metallic'){g=l.createLinearGradient(0,0,0,h);g.addColorStop(0,`rgba(255,255,255,${.15*a})`);g.addColorStop(.35,`rgba(255,255,255,${.8*a})`);g.addColorStop(.52,`rgba(0,0,0,${.42*a})`);g.addColorStop(.72,`rgba(255,255,255,${.55*a})`);g.addColorStop(1,`rgba(0,0,0,${.2*a})`);}else if(type==='satin'){g=l.createLinearGradient(0,0,w,h);g.addColorStop(0,`rgba(0,0,0,${.12*a})`);g.addColorStop(.5,`rgba(255,255,255,${.55*a})`);g.addColorStop(1,`rgba(0,0,0,${.15*a})`);}else if(type==='chrome'){g=l.createLinearGradient(0,0,0,h);[['0',.1],['.22',.8],['.32',.05],['.48',.9],['.58',.08],['.75',.65],['1',.1]].forEach(([p,v])=>g.addColorStop(+p,`rgba(255,255,255,${v*a})`));}else{g=l.createLinearGradient(0,0,w,0);g.addColorStop(0,`rgba(0,0,0,${.18*a})`);g.addColorStop(.5,`rgba(255,255,255,${.12*a})`);g.addColorStop(1,`rgba(0,0,0,${.18*a})`);}l.fillStyle=g;l.fillRect(0,0,w,h);});}

let CUSTOM_OVERLAY_IMAGE=null;
function applyCustomOverlay(mainCtx,w,h,opacity,scale,drawMask){if(!CUSTOM_OVERLAY_IMAGE)return;applyMaskedLayer(mainCtx,w,h,drawMask,l=>{l.globalAlpha=opacity/100;const iw=CUSTOM_OVERLAY_IMAGE.width*scale/100,ih=CUSTOM_OVERLAY_IMAGE.height*scale/100;const sx=Math.max(1,iw),sy=Math.max(1,ih);for(let y=0;y<h;y+=sy)for(let x=0;x<w;x+=sx)l.drawImage(CUSTOM_OVERLAY_IMAGE,x,y,iw,ih);});}



function safeClone(value){
  if(value == null) return value;
  try{
    if(typeof structuredClone === 'function') return structuredClone(value);
  }catch(e){}
  return JSON.parse(JSON.stringify(value));
}

const V7_VERSION = 9.2;
let V7_OBJECTS = [];
let V7_ACTIVE_OBJECT_ID = null;
let V7_SUPPRESS_CAPTURE = false;
let V7_RENDERING = false;
const V7_PALETTES_KEY = 'jerseyV7TeamPalettes';
const V7_PRESETS_KEY = 'jerseyV7ConstructionPresets';

function v7uid(){
  return 'obj_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,7);
}

function v7EditorElements(){
  return [...document.querySelectorAll('#designTab input[id^="txt"],#designTab select[id^="txt"],#designTab textarea[id^="txt"],#constructionTab input[id^="txt"],#constructionTab select[id^="txt"],#constructionTab textarea[id^="txt"]')]
    .filter(el => el.type !== 'file' && el.type !== 'button' && el.type !== 'radio' && el.id !== 'txtCanvasSize');
}

function v7CaptureEditorState(){
  const state={};
  v7EditorElements().forEach(el=>{
    if(el.type==='radio'){
      if(el.checked) state[el.id || ('radio:'+el.name)]={radioName:el.name,value:el.value};
    } else if(el.type==='checkbox'){
      state[el.id]=!!el.checked;
    } else {
      state[el.id]=el.value;
    }
  });
  state.__join=document.querySelector('input[name="txtJoin"]:checked')?.value || 'round';
  state.__kerning=document.querySelector('input[name="txtKerning"]:checked')?.value || 'font';
  state.__effectLayerOrder=[...EFFECT_LAYER_ORDER];
  return state;
}

function v7ApplyEditorState(state){
  if(!state) return;
  V7_SUPPRESS_CAPTURE=true;
  Object.entries(state).forEach(([id,val])=>{
    if(id.startsWith('__')) return;
    const el=document.getElementById(id);
    if(!el) return;
    if(el.type==='checkbox') el.checked=!!val;
    else if(el.type!=='file') el.value=val;
  });
  if(state.__join){
    const r=document.querySelector(`input[name="txtJoin"][value="${state.__join}"]`); if(r) r.checked=true;
  }
  if(state.__kerning){
    const r=document.querySelector(`input[name="txtKerning"][value="${state.__kerning}"]`); if(r) r.checked=true;
  }
  if(Array.isArray(state.__effectLayerOrder) && state.__effectLayerOrder.length===6){
    EFFECT_LAYER_ORDER=[...state.__effectLayerOrder]; renderLayerStackUI();
  }
  v7SyncControlDisplays();
  V7_SUPPRESS_CAPTURE=false;
}

function v7SyncControlDisplays(){
  const pairs=[
    ['txtStitchOn','txtStitchControls','block'],['txtItalicOn','txtItalicControls','flex'],['txtArchOn','txtArchControls','flex'],
    ['txtOuterStrokeOn','txtOuterStrokeControls','block'],['txtShadowOn','txtShadowControls','block'],
    ['txtInsetOn','txtInsetControls','block'],['txtTwillLayersOn','txtTwillLayersControls','block'],['txtExtrudeOn','txtExtrudeControls','block'],
    ['txtBevelOn','txtBevelControls','block'],['txtGradientOn','txtGradientControls','block'],['txtLetterEditOn','txtLetterEditControls','block'],
    ['txtWarpOn','txtWarpControls','block'],['txtTailOn','txtTailControls','block'],['txtPatternOn','txtPatternControls','block'],['txtVintageOn','txtVintageControls','block']
  ];
  pairs.forEach(([check,panel,display])=>{const c=document.getElementById(check),p=document.getElementById(panel);if(c&&p)p.style.display=c.checked?display:'none';});
  document.querySelectorAll('.val').forEach(()=>{});
  const valuePairs={
    txtStrokeWidth:'',txtStitchSize:'',txtStitchGap:'',txtStitchWidth:'',txtTextureStrength:'%',txtTextureScale:'%',txtSlant:'°',
    txtLetterSpacing:'',txtScaleX:'%',txtScaleY:'%',txtLineSpacing:'%',txtRotation:'°',txtArch:'',txtOuterStrokeWidth:'',
    txtShadowX:'',txtShadowY:'',txtShadowBlur:'',txtShadowOpacity:'%',txtInsetWidth:'',txtTwill2Width:'',txtTwill3Width:'',
    txtExtrudeDepth:'',txtExtrudeAngle:'°',txtBevelSize:'',txtBevelStrength:'%',txtGradientAngle:'°',txtFinishStrength:'%',
    txtOverlayOpacity:'%',txtOverlayScale:'%',txtLetterIndex:'',txtLetterX:'',txtLetterY:'',txtLetterRotate:'°',txtLetterScale:'%',
    txtStitchInset:'',txtStitchIrregularity:'%',txtWarpStrength:'',txtWarpCycles:'',txtTailLength:'%',txtTailWidth:'',
    txtTailCurve:'',txtTailY:'',txtPatternOpacity:'%',txtPatternScale:'%',txtPatternAngle:'°',txtVintageBaseline:'%',
    txtVintageRotation:'°',txtVintageScale:'%',txtVintageTracking:'',txtVintageWear:'%',txtVintageSeed:''
  };
  Object.entries(valuePairs).forEach(([id,suffix])=>{const el=document.getElementById(id),v=document.getElementById(id+'Val');if(el&&v)v.textContent=el.value+suffix;});
}

function v7NewObject(name='Text',state=null,transform=null){
  const base=state ? safeClone(state) : v7CaptureEditorState();
  const obj={
    id:v7uid(), name:name || 'Text', visible:true, locked:false,
    x:0,y:0,scale:1,opacity:1,
    state:base
  };
  if(transform) Object.assign(obj,transform);
  V7_OBJECTS.push(obj);
  V7_ACTIVE_OBJECT_ID=obj.id;
  v7ApplyEditorState(obj.state);
  v7RefreshObjectUI();
  return obj;
}

function v7ActiveObject(){
  return V7_OBJECTS.find(o=>o.id===V7_ACTIVE_OBJECT_ID) || null;
}

function v7CommitActive(){
  if(V7_SUPPRESS_CAPTURE || V7_RENDERING) return;
  const obj=v7ActiveObject();
  if(!obj || obj.locked) return;
  obj.state=v7CaptureEditorState();
  const t=(obj.state.txtInput||'').trim().split('\n')[0];
  if(obj.kind!=='image'&&t) obj.name=t.slice(0,28);
}

function v7SelectObject(id){
  v7CommitActive();
  const obj=V7_OBJECTS.find(o=>o.id===id); if(!obj) return;
  V7_ACTIVE_OBJECT_ID=id;
  v7ApplyEditorState(obj.state);
  if(obj.monogramKey&&document.getElementById('v92MonoFont'))document.getElementById('v92MonoFont').value=obj.state.txtFont||document.getElementById('txtFont').value;
  v7RefreshObjectUI();
  render();
}

function v7RefreshObjectUI(){
  const list=document.getElementById('v7ObjectList'); if(!list) return;
  list.innerHTML='';
  V7_OBJECTS.forEach((o,idx)=>{
    const row=document.createElement('div');row.className='object-row'+(o.id===V7_ACTIVE_OBJECT_ID?' active':'');
    const eye=document.createElement('button');eye.type='button';eye.className='eye-btn';eye.textContent=o.visible?'●':'○';eye.title=o.visible?'Hide object':'Show object';
    eye.addEventListener('click',e=>{e.stopPropagation();o.visible=!o.visible;v7RefreshObjectUI();render();});
    const name=document.createElement('button');name.type='button';name.className='object-name';name.style.textAlign='left';name.textContent=`${idx+1}. ${o.name||'Text'}`;
    if(o.kind==='image'){const badge=document.createElement('span');badge.className='v91-kind';badge.textContent='ART';name.appendChild(badge);}
    name.addEventListener('click',()=>v7SelectObject(o.id));
    const lock=document.createElement('button');lock.type='button';lock.className='mini-btn';lock.textContent=o.locked?'🔒':'🔓';lock.title='Lock/unlock object';
    lock.addEventListener('click',()=>{o.locked=!o.locked;v7RefreshObjectUI();});
    const del=document.createElement('button');del.type='button';del.className='mini-btn';del.textContent='×';del.title='Delete object';
    del.addEventListener('click',()=>v7DeleteById(o.id));
    row.append(eye,name,lock,del);list.appendChild(row);
  });
  const a=v7ActiveObject();
  ['v7ObjX','v7ObjY','v7ObjScale','v7ObjOpacity','v91ObjRotation'].forEach(id=>document.getElementById(id).disabled=!a);
  if(a){
    document.getElementById('v7ObjX').value=Math.round(a.x);
    document.getElementById('v7ObjY').value=Math.round(a.y);
    document.getElementById('v7ObjScale').value=Math.round(a.scale*100);
    document.getElementById('v7ObjOpacity').value=Math.round(a.opacity*100);
    document.getElementById('v91ObjRotation').value=Math.round(a.rotation||0);
  }
  const artControls=document.getElementById('v91ArtworkControls');
  if(artControls)artControls.style.display=a?.kind==='image'?'block':'none';
  if(a?.kind==='image'){
    document.getElementById('v91ArtworkMode').value=a.imageMode||'preserve';
    document.getElementById('v91RemoveWhite').checked=!!a.removeWhite;
    document.getElementById('v91WhiteThreshold').value=a.whiteThreshold||245;
    document.getElementById('v91WhiteThresholdVal').textContent=a.whiteThreshold||245;
  }
}

function v7DeleteById(id){
  if(V7_OBJECTS.length<=1){v7Status('v7ProjectStatus','A project must keep at least one object.');return;}
  const i=V7_OBJECTS.findIndex(o=>o.id===id); if(i<0)return;
  V7_OBJECTS.splice(i,1);
  if(V7_ACTIVE_OBJECT_ID===id){
    const next=V7_OBJECTS[Math.min(i,V7_OBJECTS.length-1)];
    V7_ACTIVE_OBJECT_ID=next.id;v7ApplyEditorState(next.state);
  }
  v7RefreshObjectUI();render();
}

function v7MoveActive(delta){
  v7CommitActive();
  const i=V7_OBJECTS.findIndex(o=>o.id===V7_ACTIVE_OBJECT_ID),j=i+delta;
  if(i<0||j<0||j>=V7_OBJECTS.length)return;
  [V7_OBJECTS[i],V7_OBJECTS[j]]=[V7_OBJECTS[j],V7_OBJECTS[i]];
  v7RefreshObjectUI();render();
}

let LIVE_PREVIEW_RAF=0;
function syncLivePreviewImage(){
  const canvas=document.getElementById('txtCanvas');
  const img=document.getElementById('txtLiveImage');
  if(!canvas || !img || !canvas.width || !canvas.height) return;
  cancelAnimationFrame(LIVE_PREVIEW_RAF);
  LIVE_PREVIEW_RAF=requestAnimationFrame(()=>{
    try{
      // A data-URL-backed <img> is recognized by iOS Safari as a normal image,
      // enabling the native long-press menu and Save to Photos / Save Image flow.
      const liveSrc=canvas.toDataURL('image/png');
      img.src=liveSrc;
      const modalImg=document.getElementById('previewModalImage');
      if(modalImg) modalImg.src=liveSrc;
    }catch(err){
      console.warn('Live PNG preview update failed.',err);
    }
  });
}

const V91_IMAGE_CACHE=new Map();
let V91_TEXT_VISIBLE=true;
function v91SetTextVisibility(show,rerender=true){V91_TEXT_VISIBLE=!!show;const btn=document.getElementById('v91TextVisibilityBtn'),box=document.getElementById('v91ShowText');if(btn){btn.textContent=V91_TEXT_VISIBLE?'Text: On':'Text: Off';btn.classList.toggle('active',V91_TEXT_VISIBLE);btn.setAttribute('aria-pressed',String(V91_TEXT_VISIBLE));}if(box)box.checked=V91_TEXT_VISIBLE;if(rerender)render();}
let V92_ARTWORK_VISIBLE=true;
function v92SetArtworkVisibility(show,rerender=true){V92_ARTWORK_VISIBLE=!!show;const btn=document.getElementById('v92ArtworkVisibilityBtn'),box=document.getElementById('v92ShowArtwork');if(btn){btn.textContent=V92_ARTWORK_VISIBLE?'Art: On':'Art: Off';btn.classList.toggle('active',V92_ARTWORK_VISIBLE);btn.setAttribute('aria-pressed',String(V92_ARTWORK_VISIBLE));}if(box)box.checked=V92_ARTWORK_VISIBLE;if(rerender)render();}
function v91GetImage(obj){
  if(V91_IMAGE_CACHE.has(obj.id))return V91_IMAGE_CACHE.get(obj.id);
  if(!obj.imageSrc)return null;
  const img=new Image();
  img.onload=()=>{V91_IMAGE_CACHE.set(obj.id,img);render();};
  img.onerror=()=>console.warn('Artwork could not be decoded:',obj.name);
  img.src=obj.imageSrc;V91_IMAGE_CACHE.set(obj.id,null);return null;
}
function v91DilateMask(mask,radius){
  const c=document.createElement('canvas');c.width=mask.width;c.height=mask.height;const x=c.getContext('2d');
  radius=Math.max(0,Math.round(radius));if(!radius){x.drawImage(mask,0,0);return c;}
  for(let a=0;a<Math.PI*2;a+=Math.max(.16,1/radius)){x.drawImage(mask,Math.cos(a)*radius,Math.sin(a)*radius);}x.drawImage(mask,0,0);return c;
}
function v91PaintMask(mask,color){const c=document.createElement('canvas');c.width=mask.width;c.height=mask.height;const x=c.getContext('2d');x.drawImage(mask,0,0);x.globalCompositeOperation='source-in';x.fillStyle=color;x.fillRect(0,0,c.width,c.height);return c;}
function v91StateNum(st,id,fallback=0){const n=Number(st?.[id]);return Number.isFinite(n)?n:fallback;}
function renderArtworkObject(canvas,obj,w,h){
  canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d'),img=v91GetImage(obj);if(!img)return;
  const st=obj.state||{},mask=document.createElement('canvas');mask.width=w;mask.height=h;const mc=mask.getContext('2d',{willReadFrequently:true});
  const maxW=w*.78,maxH=h*.78,ratio=Math.min(maxW/img.naturalWidth,maxH/img.naturalHeight),dw=img.naturalWidth*ratio,dh=img.naturalHeight*ratio,dx=(w-dw)/2,dy=(h-dh)/2;
  mc.drawImage(img,dx,dy,dw,dh);
  if(obj.removeWhite){const d=mc.getImageData(0,0,w,h),p=d.data,th=obj.whiteThreshold||245;for(let i=0;i<p.length;i+=4){if(p[i]>=th&&p[i+1]>=th&&p[i+2]>=th)p[i+3]=0;else if(p[i+3])p[i]=p[i+1]=p[i+2]=255;}mc.putImageData(d,0,0);}else{mc.globalCompositeOperation='source-in';mc.fillStyle='#fff';mc.fillRect(0,0,w,h);mc.globalCompositeOperation='source-over';}
  const drawMask=x=>x.drawImage(mask,0,0),fill=st.txtFillHex||'#FF0000',stroke=st.txtStrokeHex||'#0000FF',outer=st.txtOuterStrokeHex||'#FFFFFF';
  const sw=st.txtStrokeOn?v91StateNum(st,'txtStrokeWidth',10):0,ow=st.txtOuterStrokeOn?v91StateNum(st,'txtOuterStrokeWidth',20):0;
  const outerMask=ow?v91DilateMask(mask,ow):null,strokeMask=sw?v91DilateMask(mask,sw):null;
  if(st.txtShadowOn){ctx.save();ctx.globalAlpha=v91StateNum(st,'txtShadowOpacity',80)/100;ctx.filter=`blur(${v91StateNum(st,'txtShadowBlur',0)}px)`;ctx.drawImage(v91PaintMask(mask,st.txtShadowHex||'#000'),v91StateNum(st,'txtShadowX',12),v91StateNum(st,'txtShadowY',12));ctx.restore();}
  if(st.txtExtrudeOn){const depth=v91StateNum(st,'txtExtrudeDepth',14),ang=v91StateNum(st,'txtExtrudeAngle',45)*Math.PI/180,paint=v91PaintMask(mask,st.txtExtrudeHex||'#333');for(let i=depth;i>0;i--)ctx.drawImage(paint,Math.cos(ang)*i,Math.sin(ang)*i);}
  if(st.txtTwillLayersOn){ctx.drawImage(v91PaintMask(v91DilateMask(mask,v91StateNum(st,'txtTwill3Width',40)),st.txtTwill3Hex||'#00FF00'),0,0);ctx.drawImage(v91PaintMask(v91DilateMask(mask,v91StateNum(st,'txtTwill2Width',24)),st.txtTwill2Hex||'#0000FF'),0,0);}
  if(outerMask)ctx.drawImage(v91PaintMask(outerMask,outer),0,0);
  if(strokeMask)ctx.drawImage(v91PaintMask(strokeMask,stroke),0,0);
  if(obj.imageMode==='preserve'){const original=document.createElement('canvas');original.width=w;original.height=h;const oc=original.getContext('2d');oc.drawImage(img,dx,dy,dw,dh);oc.globalCompositeOperation='destination-in';oc.drawImage(mask,0,0);ctx.drawImage(original,0,0);}else{const face=document.createElement('canvas');face.width=w;face.height=h;const fc=face.getContext('2d');if(st.txtGradientOn){const a=v91StateNum(st,'txtGradientAngle',90)*Math.PI/180,g=fc.createLinearGradient(w/2-Math.cos(a)*w/2,h/2-Math.sin(a)*h/2,w/2+Math.cos(a)*w/2,h/2+Math.sin(a)*h/2);g.addColorStop(0,st.txtGradientAHex||fill);g.addColorStop(1,st.txtGradientBHex||fill);fc.fillStyle=g;}else fc.fillStyle=fill;fc.fillRect(0,0,w,h);fc.globalCompositeOperation='destination-in';fc.drawImage(mask,0,0);ctx.drawImage(face,0,0);}
  applyTextureOverlay(ctx,w,h,st.txtTexture,v91StateNum(st,'txtTextureStrength',35),v91StateNum(st,'txtTextureScale',100),st.txtTextureHex||'#fff',drawMask);
  if(st.txtPatternOn)applyGeneratedPattern(ctx,w,h,{on:true,type:st.txtPatternType,a:st.txtPatternAHex,b:st.txtPatternBHex,opacity:v91StateNum(st,'txtPatternOpacity',45),scale:v91StateNum(st,'txtPatternScale',100),angle:v91StateNum(st,'txtPatternAngle',45)*Math.PI/180,text:st.txtPatternText||'TEAM'},drawMask);
  if(st.txtBevelOn)applyBevel(ctx,w,h,v91StateNum(st,'txtBevelSize',4),v91StateNum(st,'txtBevelStrength',40),drawMask);
  applyFinishOverlay(ctx,w,h,st.txtFinish,v91StateNum(st,'txtFinishStrength',35),drawMask);
  if(CUSTOM_OVERLAY_IMAGE)applyCustomOverlay(ctx,w,h,v91StateNum(st,'txtOverlayOpacity',50),v91StateNum(st,'txtOverlayScale',100),drawMask);
  if(st.txtStitchOn){const band=v91DilateMask(mask,Math.max(2,v91StateNum(st,'txtStitchWidth',2)*2));const bc=band.getContext('2d');bc.globalCompositeOperation='destination-out';bc.drawImage(mask,0,0);const dots=document.createElement('canvas');dots.width=w;dots.height=h;const dc=dots.getContext('2d'),gap=Math.max(3,v91StateNum(st,'txtStitchGap',8)),size=Math.max(1,v91StateNum(st,'txtStitchWidth',2));for(let y=0;y<h;y+=gap)for(let x=(y/gap%2)*gap/2;x<w;x+=gap){dc.fillStyle=st.txtStitchHex||'#fff';dc.fillRect(x,y,size*2,size);}dc.globalCompositeOperation='destination-in';dc.drawImage(band,0,0);ctx.drawImage(dots,0,0);}
  if(st.txtVintageOn)applyVintageWear(ctx,w,h,v91StateNum(st,'txtVintageWear',0),v91StateNum(st,'txtVintageSeed',57),drawMask);
}

function render(){
  if(V7_RENDERING) return;
  if(!V7_OBJECTS.length){
    try{ renderSingle(); syncLivePreviewImage(); }catch(err){ console.error('Direct render failed',err); }
    return;
  }

  const main=document.getElementById('txtCanvas');
  let liveState=null;
  try{
    liveState=v7CaptureEditorState();
    v7CommitActive();
    V7_RENDERING=true;

    const active=v7ActiveObject();
    const activeState=active ? safeClone(active.state) : safeClone(liveState);
    const sizeEl=document.getElementById('txtCanvasSize');
    const parts=(sizeEl && sizeEl.value ? sizeEl.value : '1024x512').split('x').map(Number);
    const w=parts[0]||1024, h=parts[1]||512;
    main.width=w; main.height=h;
    const m=main.getContext('2d');
    m.clearRect(0,0,w,h);

    V7_OBJECTS.forEach(obj=>{
      if(!obj.visible) return;
      if(obj.kind!=='image'&&!V91_TEXT_VISIBLE) return;
      if(obj.kind==='image'&&!V92_ARTWORK_VISIBLE) return;
      v7ApplyEditorState(obj.state);
      const temp=document.createElement('canvas');
      if(obj.kind==='image')renderArtworkObject(temp,obj,w,h);else renderSingle(temp);
      m.save();
      m.globalAlpha=Math.max(0,Math.min(1,Number(obj.opacity ?? 1)));
      m.translate(w/2+Number(obj.x||0),h/2+Number(obj.y||0));
      m.rotate(Number(obj.rotation||0)*Math.PI/180);
      const sc=Number(obj.scale||1) || 1;
      m.scale(sc,sc);
      m.translate(-w/2,-h/2);
      if(obj.interlockGap>0){m.save();m.globalCompositeOperation='destination-out';m.globalAlpha=1;m.drawImage(v91DilateMask(temp,obj.interlockGap),0,0,w,h);m.restore();}
      m.drawImage(temp,0,0,w,h);
      m.restore();
    });

    if(activeState) v7ApplyEditorState(activeState);
  }catch(err){
    console.error('Composite render failed; using live mobile fallback.',err);
    try{
      if(liveState) v7ApplyEditorState(liveState);
      renderSingle(main);
    }catch(fallbackErr){
      console.error('Fallback render failed',fallbackErr);
    }
  }finally{
    V7_RENDERING=false;
    try{ v7RefreshObjectUI(); }catch(e){}
    syncLivePreviewImage();
  }
}

function v7CloneObject(source,overrides={}){
  const c=safeClone(source);
  c.id=v7uid(); c.name=(source.name||'Text')+' copy'; c.x+=12;c.y+=12;
  Object.assign(c,overrides);return c;
}

function v7StyleState(state){
  const copy=safeClone(state);
  ['txtInput'].forEach(k=>delete copy[k]);
  return copy;
}

function v7ApplyStyleState(style){
  const cur=v7CaptureEditorState();
  const text=cur.txtInput;
  Object.assign(cur,safeClone(style));
  cur.txtInput=text;
  v7ApplyEditorState(cur);
  v7CommitActive(); render();
}

function v7PaletteFromCurrent(){
  const ids=['txtFillHex','txtStrokeHex','txtOuterStrokeHex','txtShadowHex','txtStitchHex','txtStitch2Hex','txtTextureHex','txtInsetHex','txtTwill2Hex','txtTwill3Hex','txtExtrudeHex','txtGradientAHex','txtGradientBHex','txtLetterHex','txtTailHex','txtPatternAHex','txtPatternBHex'];
  const st=v7CaptureEditorState(); return ids.map(id=>st[id]).filter(v=>/^#[0-9A-Fa-f]{6}$/.test(v||''));
}
function v7UniqueColors(arr){return [...new Set(arr.map(x=>x.toUpperCase()))];}
const V7_MEMORY_STORE={};
function v7GetLocal(key){
  try{
    const raw=localStorage.getItem(key);
    if(raw!==null){const parsed=JSON.parse(raw);V7_MEMORY_STORE[key]=parsed;return parsed;}
  }catch{}
  return safeClone(V7_MEMORY_STORE[key]||[]);
}
function v7SetLocal(key,val){
  V7_MEMORY_STORE[key]=safeClone(val);
  try{localStorage.setItem(key,JSON.stringify(val));}catch{}
}

function v7RenderPalettes(){
  const host=document.getElementById('v7PaletteList');if(!host)return;host.innerHTML='';
  v7GetLocal(V7_PALETTES_KEY).forEach((p,i)=>{
    const row=document.createElement('div');row.className='palette-row';
    const left=document.createElement('button');left.type='button';left.style.textAlign='left';
    left.innerHTML=`<strong>${v7Escape(p.name)}</strong><div class="palette-swatches">${p.colors.map(c=>`<span class="palette-dot" style="background:${c}" title="${c}"></span>`).join('')}</div>`;
    left.addEventListener('click',()=>v7ApplyPalette(p.colors));
    const rename=document.createElement('button');rename.type='button';rename.textContent='Rename';rename.onclick=()=>{const n=prompt('Palette name',p.name);if(n){const all=v7GetLocal(V7_PALETTES_KEY);all[i].name=n.trim();v7SetLocal(V7_PALETTES_KEY,all);v7RenderPalettes();}};
    const del=document.createElement('button');del.type='button';del.textContent='×';del.onclick=()=>{const all=v7GetLocal(V7_PALETTES_KEY);all.splice(i,1);v7SetLocal(V7_PALETTES_KEY,all);v7RenderPalettes();};
    row.append(left,rename,del);host.appendChild(row);
  });
}
function v7ApplyPalette(colors){
  if(!colors.length)return;
  const map=['txtFillHex','txtStrokeHex','txtOuterStrokeHex','txtShadowHex','txtStitchHex','txtStitch2Hex','txtTextureHex','txtInsetHex','txtTwill2Hex','txtTwill3Hex','txtExtrudeHex','txtGradientAHex','txtGradientBHex','txtLetterHex','txtTailHex','txtPatternAHex','txtPatternBHex'];
  map.forEach((id,i)=>{const hex=colors[i%colors.length],h=document.getElementById(id);if(!h)return;h.value=hex;const picker=document.getElementById(id.replace('Hex','Color'));if(picker)picker.value=hex.toLowerCase();});
  v7CommitActive();render();
}
function v7RenderPresets(){
  const host=document.getElementById('v7PresetList');if(!host)return;host.innerHTML='';
  v7GetLocal(V7_PRESETS_KEY).forEach((p,i)=>{
    const row=document.createElement('div');row.className='preset-row';
    const apply=document.createElement('button');apply.type='button';apply.textContent=p.name;apply.style.textAlign='left';apply.onclick=()=>v7ApplyStyleState(p.state);
    const rename=document.createElement('button');rename.type='button';rename.textContent='Rename';rename.onclick=()=>{const n=prompt('Preset name',p.name);if(n){const all=v7GetLocal(V7_PRESETS_KEY);all[i].name=n.trim();v7SetLocal(V7_PRESETS_KEY,all);v7RenderPresets();}};
    const del=document.createElement('button');del.type='button';del.textContent='×';del.onclick=()=>{const all=v7GetLocal(V7_PRESETS_KEY);all.splice(i,1);v7SetLocal(V7_PRESETS_KEY,all);v7RenderPresets();};
    row.append(apply,rename,del);host.appendChild(row);
  });
}
function v7Escape(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function v7Status(id,msg){const el=document.getElementById(id);if(el){el.textContent=msg;setTimeout(()=>{if(el.textContent===msg)el.textContent='';},3500)}}

function v7ProjectData(){
  v7CommitActive();
  return {
    app:'Jersey Text & Artwork Studio',version:V7_VERSION,name:document.getElementById('v7ProjectName').value||'CFB Wordmark Project',
    created:new Date().toISOString(),canvasSize:document.getElementById('txtCanvasSize').value,
    activeObjectId:V7_ACTIVE_OBJECT_ID,objects:safeClone(V7_OBJECTS),
    effectLayerOrder:[...EFFECT_LAYER_ORDER],textVisible:V91_TEXT_VISIBLE,artworkVisible:V92_ARTWORK_VISIBLE,
    palettes:v7GetLocal(V7_PALETTES_KEY),presets:v7GetLocal(V7_PRESETS_KEY)
  };
}
function v7DownloadJSON(){
  const data=v7ProjectData(),blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
  const a=document.createElement('a'),url=URL.createObjectURL(blob);
  a.href=url;a.download=(data.name||'cfb-wordmark-project').replace(/[^a-z0-9_-]+/gi,'_')+'.json';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);v7Status('v7ProjectStatus','Editable project downloaded.');
}
async function v7LoadJSONFile(file){
  try{
    const data=JSON.parse(await file.text());
    if(!data || !Array.isArray(data.objects) || !data.objects.length) throw new Error('Invalid V7 project');
    V91_IMAGE_CACHE.clear();V7_OBJECTS=data.objects;V7_ACTIVE_OBJECT_ID=data.activeObjectId && V7_OBJECTS.some(o=>o.id===data.activeObjectId)?data.activeObjectId:V7_OBJECTS[0].id;
    if(data.canvasSize && [...document.getElementById('txtCanvasSize').options].some(o=>o.value===data.canvasSize))document.getElementById('txtCanvasSize').value=data.canvasSize;
    if(Array.isArray(data.effectLayerOrder)&&data.effectLayerOrder.length===6)EFFECT_LAYER_ORDER=data.effectLayerOrder;
    v91SetTextVisibility(data.textVisible!==false,false);
    v92SetArtworkVisibility(data.artworkVisible!==false,false);
    if(Array.isArray(data.palettes))v7SetLocal(V7_PALETTES_KEY,data.palettes);
    if(Array.isArray(data.presets))v7SetLocal(V7_PRESETS_KEY,data.presets);
    document.getElementById('v7ProjectName').value=data.name||'CFB Wordmark Project';
    v7ApplyEditorState(v7ActiveObject().state);v7RenderPalettes();v7RenderPresets();renderLayerStackUI();v7RefreshObjectUI();render();
    v7Status('v7ProjectStatus','Project loaded successfully.');
  }catch(err){v7Status('v7ProjectStatus','Could not load that project JSON.');}
}

function v7BuildObjects(specs){
  v7CommitActive();
  const base=v7ActiveObject()?safeClone(v7ActiveObject().state):v7CaptureEditorState();
  const made=[];
  specs.forEach((sp,i)=>{
    const st=safeClone(base);
    st.txtInput=sp.text || 'TEXT';
    if(sp.arch!==undefined){st.txtArchOn=!!sp.arch;st.txtArch=String(sp.arch||35);}
    if(sp.font)st.txtFont=sp.font;
    if(sp.letterSpacing!==undefined)st.txtLetterSpacing=String(sp.letterSpacing);
    made.push({id:v7uid(),name:(sp.text||'Text').slice(0,28),visible:true,locked:false,x:sp.x||0,y:sp.y||0,scale:sp.scale??1,opacity:1,state:st});
  });
  V7_OBJECTS=made;V7_ACTIVE_OBJECT_ID=made[made.length-1].id;v7ApplyEditorState(v7ActiveObject().state);v7RefreshObjectUI();render();
}

function v7BuildTemplate(type){
  const A=(document.getElementById('v7MonoA').value||'B').toUpperCase(),B=(document.getElementById('v7MonoB').value||'S').toUpperCase(),C=(document.getElementById('v7MonoC').value||'U').toUpperCase();
  const school=(document.getElementById('v7SchoolName').value||'BIG SKY STATE').toUpperCase(),nick=(document.getElementById('v7Nickname').value||'FLYERS').toUpperCase();
  let sp=[];
  if(type==='interlock2')sp=[{text:A,x:-58,scale:.72},{text:B,x:58,scale:.72}];
  if(type==='interlock3')sp=[{text:A,x:-72,scale:.68},{text:B,x:0,scale:.75},{text:C,x:72,scale:.68}];
  if(type==='diagonal')sp=[{text:A,x:-55,y:42,scale:.68},{text:B,x:55,y:-42,scale:.68}];
  if(type==='stackedMono')sp=[{text:A,y:-80,scale:.56},{text:B,y:0,scale:.56},{text:C,y:80,scale:.56}];
  if(type==='schoolStack')sp=[{text:school,y:-72,scale:.78,letterSpacing:6},{text:nick,y:88,scale:.55,letterSpacing:14}];
  if(type==='archStack')sp=[{text:school,y:-72,scale:.78,arch:32,letterSpacing:5},{text:nick,y:92,scale:.55,letterSpacing:14}];
  if(type==='schoolMono')sp=[{text:A+B,x:-275,scale:.38},{text:school,x:120,y:-38,scale:.56},{text:nick,x:120,y:62,scale:.42,letterSpacing:12}];
  if(type==='threeLine')sp=[{text:'UNIVERSITY OF',y:-105,scale:.38,letterSpacing:12},{text:school,y:0,scale:.68,letterSpacing:4},{text:nick,y:105,scale:.38,letterSpacing:16}];
  if(sp.length){v7BuildObjects(sp);v7Status('v7BuilderStatus','Editable lockup created. Select any object layer to refine it.');}
}

function v92UpdateMonogram(create=false){
  const count=Number(document.getElementById('v92MonoCount').value)||2,layout=document.getElementById('v92MonoLayout').value,overlap=Number(document.getElementById('v92MonoOverlap').value)||0,whole=Number(document.getElementById('v92MonoRotation').value)||0,gap=Number(document.getElementById('v92MonoGap').value)||0,firstTop=document.getElementById('v92MonoFirstTop').checked,monoFont=document.getElementById('v92MonoFont').value||document.getElementById('txtFont').value;
  const letters=['A','B','C'].slice(0,count).map((k,i)=>({key:k,text:(document.getElementById('v7Mono'+k).value||k).toUpperCase(),mx:Number(document.getElementById('v92'+k+'X').value)||0,my:Number(document.getElementById('v92'+k+'Y').value)||0,mr:Number(document.getElementById('v92'+k+'R').value)||0,ms:(Number(document.getElementById('v92'+k+'S').value)||100)/100,index:i}));
  const distance=Math.max(18,175*(1-overlap/100));
  letters.forEach((l,i)=>{
    const center=(count-1)/2,u=i-center;
    if(layout==='horizontal'){l.x=u*distance;l.y=0;l.rot=0;}
    else if(layout==='stacked'){l.x=0;l.y=u*distance;l.rot=0;}
    else if(layout==='diagonal'){l.x=u*distance;l.y=(firstTop?u:-u)*distance;l.rot=0;}
    else{const angle=(-90+i*(360/count))*Math.PI/180;l.x=Math.cos(angle)*distance*.62;l.y=Math.sin(angle)*distance*.62;l.rot=(-90+i*(360/count))+90;}
    l.x+=l.mx;l.y+=l.my;l.rot+=whole+l.mr;
  });
  const old=new Map(V7_OBJECTS.filter(o=>o.monogramKey).map(o=>[o.monogramKey,o])),others=V7_OBJECTS.filter(o=>!o.monogramKey),base=v7ActiveObject()?safeClone(v7ActiveObject().state):v7CaptureEditorState();
  let monos=letters.map(l=>{let o=old.get(l.key);if(!o){o={id:v7uid(),name:'Monogram '+l.text,visible:true,locked:false,x:0,y:0,scale:.72,opacity:1,rotation:0,state:safeClone(base),monogramKey:l.key};}o.state.txtInput=l.text;o.state.txtFont=monoFont;o.name='Monogram '+l.text;o.x=l.x;o.y=l.y;o.rotation=l.rot;o.scale=.72*l.ms;o.interlockGap=gap;return o;});
  if(firstTop)monos=[...monos.slice(1),monos[0]];
  V7_OBJECTS=[...others,...monos];V7_ACTIVE_OBJECT_ID=monos[monos.length-1].id;v7ApplyEditorState(v7ActiveObject().state);v7RefreshObjectUI();render();v7Status('v7BuilderStatus',create?'Custom interlocking monogram created.':'Monogram updated.');
}
function v92ResetMonogramControls(){['AX','AY','AR','BX','BY','BR','CX','CY','CR'].forEach(k=>document.getElementById('v92'+k).value=0);['AS','BS','CS'].forEach(k=>document.getElementById('v92'+k).value=100);document.getElementById('v92MonoOverlap').value=62;document.getElementById('v92MonoRotation').value=0;document.getElementById('v92MonoGap').value=5;document.getElementById('v92MonoOverlapVal').textContent='62%';document.getElementById('v92MonoRotationVal').textContent='0°';document.getElementById('v92MonoGapVal').textContent='5';if(V7_OBJECTS.some(o=>o.monogramKey))v92UpdateMonogram();}



function setupPreviewViewerV84(){
  const wrap=document.getElementById('previewWrap');
  const liveImg=document.getElementById('txtLiveImage');
  const modal=document.getElementById('previewModal');
  const stage=document.getElementById('previewModalStage');
  const modalImg=document.getElementById('previewModalImage');
  const closeBtn=document.getElementById('previewModalClose');
  const darkBtn=document.getElementById('previewDarkBtn');
  const lightBtn=document.getElementById('previewLightBtn');
  if(!wrap || !liveImg || !modal || !stage) return;

  let previewBg='dark';
  const applyBg=(mode)=>{
    previewBg=mode==='light'?'light':'dark';
    wrap.classList.toggle('preview-light',previewBg==='light');
    wrap.classList.toggle('preview-dark',previewBg==='dark');
    stage.classList.toggle('preview-light',previewBg==='light');
    stage.classList.toggle('preview-dark',previewBg==='dark');
    darkBtn?.classList.toggle('active',previewBg==='dark');
    lightBtn?.classList.toggle('active',previewBg==='light');
    darkBtn?.setAttribute('aria-pressed',String(previewBg==='dark'));
    lightBtn?.setAttribute('aria-pressed',String(previewBg==='light'));
  };

  darkBtn?.addEventListener('click',(e)=>{e.stopPropagation();applyBg('dark');});
  lightBtn?.addEventListener('click',(e)=>{e.stopPropagation();applyBg('light');});

  const openPreview=()=>{
    if(modalImg && liveImg.src) modalImg.src=liveImg.src;
    modal.classList.add('open');
    modal.setAttribute('aria-hidden','false');
    document.body.style.overflow='hidden';
    closeBtn?.focus({preventScroll:true});
  };
  const closePreview=()=>{
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden','true');
    document.body.style.overflow='';
  };

  // A quick tap enlarges. Native press-and-hold remains available because the target stays a real <img>.
  liveImg.addEventListener('click',openPreview);
  modalImg?.addEventListener('click',closePreview);
  closeBtn?.addEventListener('click',closePreview);
  modal.addEventListener('click',(e)=>{if(e.target===modal) closePreview();});
  document.addEventListener('keydown',(e)=>{if(e.key==='Escape' && modal.classList.contains('open')) closePreview();});

  applyBg('dark');
}

function setupMobileV8(){
  const fontSelect=document.getElementById('txtFont');
  const fontSearch=document.getElementById('txtFontSearch');
  const fontHint=document.getElementById('txtFontSearchHint');

  if(fontSelect && fontSearch){
    const originalGroups=[...fontSelect.children].map(group=>{
      if(group.tagName==='OPTGROUP'){
        return {
          type:'group',
          label:group.label,
          options:[...group.children].map(o=>({value:o.value,text:o.textContent,selected:o.selected}))
        };
      }
      return {type:'option',value:group.value,text:group.textContent,selected:group.selected};
    });

    const rebuild=(query='')=>{
      const q=query.trim().toLowerCase();
      const current=fontSelect.value;
      fontSelect.innerHTML='';
      let shown=0;

      originalGroups.forEach(item=>{
        if(item.type==='group'){
          const matches=item.options.filter(o=>!q || o.text.toLowerCase().includes(q));
          if(!matches.length) return;
          const g=document.createElement('optgroup');
          g.label=item.label;
          matches.forEach(o=>{
            const opt=document.createElement('option');
            opt.value=o.value;
            opt.textContent=o.text;
            if(o.value===current) opt.selected=true;
            g.appendChild(opt);
            shown++;
          });
          fontSelect.appendChild(g);
        }else if(!q || item.text.toLowerCase().includes(q)){
          const opt=document.createElement('option');
          opt.value=item.value; opt.textContent=item.text;
          if(item.value===current) opt.selected=true;
          fontSelect.appendChild(opt);
          shown++;
        }
      });

      if(fontHint) fontHint.textContent=q ? `${shown} matching font${shown===1?'':'s'}` : 'Type to filter the font library.';
    };

    fontSearch.addEventListener('input',()=>rebuild(fontSearch.value));
    fontSearch.addEventListener('search',()=>rebuild(fontSearch.value));
  }

  document.querySelectorAll('[data-jump]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const target=document.getElementById(btn.dataset.jump);
      if(!target) return;
      const designBtn=document.querySelector('.tab-btn[data-tab="designTab"]');
      if(designBtn && !document.getElementById('designTab').classList.contains('active')) designBtn.click();
      setTimeout(()=>{
        const field=target.closest('.fieldblock') || target;
        field.scrollIntoView({behavior:'smooth',block:'center'});
        if(target.matches('input,textarea,select')) target.focus({preventScroll:true});
      },60);
    });
  });

  document.getElementById('mobileDownloadBtn')?.addEventListener('click',()=>{
    const dl=document.getElementById('txtDownloadBtn');
    if(dl) dl.click();
  });

  const desktopDownload = document.getElementById('txtDownloadBtn');
  const mobileDownload = document.getElementById('mobileDownloadBtn');
  if (desktopDownload) desktopDownload.textContent = 'Download PNG';
  if (mobileDownload) mobileDownload.textContent = 'DOWNLOAD PNG';

  // Mobile bottom nav returns the controls to a predictable point after changing sections.
  document.querySelectorAll('.mobile-bottom-nav .tab-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      if(window.innerWidth<=760){
        setTimeout(()=>{
          const panel=document.getElementById(btn.dataset.tab);
          if(panel){
            const y=panel.getBoundingClientRect().top + window.scrollY - Math.min(window.innerHeight*.38,300);
            window.scrollTo({top:Math.max(0,y),behavior:'smooth'});
          }
        },40);
      }
    });
  });
}

function setupBakedEffectGrid(){
  const select=document.getElementById('txtTexture');
  const grid=document.getElementById('txtEffectGrid');
  if(!select || !grid) return;

  const cleanLabel=(txt)=>String(txt)
    .replace(/^\d+\s*[—-]\s*/,'')
    .replace(/^Endzone\s*[—-]\s*/,'Endzone — ');

  function sync(){
    grid.querySelectorAll('.effect-pick').forEach(btn=>{
      btn.classList.toggle('active',btn.dataset.effect===select.value);
      btn.setAttribute('aria-pressed',btn.dataset.effect===select.value?'true':'false');
    });
  }

  grid.innerHTML='';
  [...select.options].forEach(opt=>{
    const btn=document.createElement('button');
    btn.type='button';
    btn.className='effect-pick';
    btn.dataset.effect=opt.value;
    btn.textContent=cleanLabel(opt.textContent);
    btn.title=opt.textContent;
    btn.addEventListener('click',()=>{
      select.value=opt.value;
      select.dispatchEvent(new Event('change',{bubbles:true}));
      sync();
    });
    grid.appendChild(btn);
  });

  select.addEventListener('change',sync);
  select.addEventListener('input',sync);
  sync();
}

function v7SetupWorkspace(){
  const monoFontSelect=document.getElementById('v92MonoFont'),mainFontSelect=document.getElementById('txtFont');
  monoFontSelect.innerHTML=mainFontSelect.innerHTML;
  monoFontSelect.value=mainFontSelect.value;
  new MutationObserver(()=>{const keep=monoFontSelect.value;monoFontSelect.innerHTML=mainFontSelect.innerHTML;if([...monoFontSelect.options].some(o=>o.value===keep))monoFontSelect.value=keep;}).observe(mainFontSelect,{childList:true,subtree:true});
  // Initial object uses the already-loaded editor defaults.
  if(!V7_OBJECTS.length){
    const initial={id:v7uid(),name:(document.getElementById('txtInput').value||'JERSEY TEXT').slice(0,28),visible:true,locked:false,x:0,y:0,scale:1,opacity:1,state:v7CaptureEditorState()};
    V7_OBJECTS=[initial];V7_ACTIVE_OBJECT_ID=initial.id;
  }
  document.getElementById('v7AddObject').onclick=()=>{v7CommitActive();const base=v7ActiveObject()?safeClone(v7ActiveObject().state):v7CaptureEditorState();base.txtInput='NEW TEXT';v7NewObject('NEW TEXT',base,{y:30,scale:.75});render();};
  document.getElementById('v91AddArtwork').onclick=()=>document.getElementById('v91ArtworkFile').click();
  document.getElementById('v91QuickAddArtwork').onclick=()=>document.getElementById('v91ArtworkFile').click();
  document.getElementById('v91TextVisibilityBtn').onclick=()=>v91SetTextVisibility(!V91_TEXT_VISIBLE);
  document.getElementById('v91ShowText').addEventListener('change',e=>v91SetTextVisibility(e.target.checked));
  document.getElementById('v92ArtworkVisibilityBtn').onclick=()=>v92SetArtworkVisibility(!V92_ARTWORK_VISIBLE);
  document.getElementById('v92ShowArtwork').addEventListener('change',e=>v92SetArtworkVisibility(e.target.checked));
  document.getElementById('v91ArtworkFile').addEventListener('change',e=>{const file=e.target.files?.[0];if(!file)return;const reader=new FileReader();reader.onload=ev=>{const probe=new Image();probe.onload=()=>{v7CommitActive();const base=v7ActiveObject()?safeClone(v7ActiveObject().state):v7CaptureEditorState();const obj={id:v7uid(),kind:'image',name:file.name.replace(/\.[^.]+$/,'').slice(0,28)||'Artwork',visible:true,locked:false,x:0,y:0,scale:1,opacity:1,rotation:0,state:base,imageSrc:ev.target.result,imageMode:'preserve',removeWhite:false,whiteThreshold:245};V7_OBJECTS.push(obj);V7_ACTIVE_OBJECT_ID=obj.id;V91_IMAGE_CACHE.set(obj.id,probe);v91SetTextVisibility(false,false);v7ApplyEditorState(obj.state);v7RefreshObjectUI();render();v7Status('v7ProjectStatus','Artwork added. Text hidden—use Text: Off to restore it.');};probe.onerror=()=>v7Status('v7ProjectStatus','That image could not be opened.');probe.src=ev.target.result;};reader.readAsDataURL(file);e.target.value='';});
  document.getElementById('v7DuplicateObject').onclick=()=>{v7CommitActive();const a=v7ActiveObject();if(!a)return;const c=v7CloneObject(a);V7_OBJECTS.push(c);V7_ACTIVE_OBJECT_ID=c.id;v7ApplyEditorState(c.state);v7RefreshObjectUI();render();};
  document.getElementById('v7MoveUp').onclick=()=>v7MoveActive(1);
  document.getElementById('v7MoveDown').onclick=()=>v7MoveActive(-1);
  document.getElementById('v7DeleteObject').onclick=()=>{const a=v7ActiveObject();if(a)v7DeleteById(a.id);};
  ['v7ObjX','v7ObjY','v7ObjScale','v7ObjOpacity','v91ObjRotation'].forEach(id=>document.getElementById(id).addEventListener('input',()=>{
    const a=v7ActiveObject();if(!a||a.locked)return;
    a.x=Number(document.getElementById('v7ObjX').value)||0;a.y=Number(document.getElementById('v7ObjY').value)||0;
    a.scale=Math.max(.1,Math.min(3,(Number(document.getElementById('v7ObjScale').value)||100)/100));
    a.opacity=Math.max(0,Math.min(1,(Number(document.getElementById('v7ObjOpacity').value)||100)/100));render();
    a.rotation=Math.max(-180,Math.min(180,Number(document.getElementById('v91ObjRotation').value)||0));render();
  }));
  ['v91ArtworkMode','v91RemoveWhite','v91WhiteThreshold'].forEach(id=>document.getElementById(id).addEventListener('input',()=>{const a=v7ActiveObject();if(!a||a.kind!=='image'||a.locked)return;a.imageMode=document.getElementById('v91ArtworkMode').value;a.removeWhite=document.getElementById('v91RemoveWhite').checked;a.whiteThreshold=Number(document.getElementById('v91WhiteThreshold').value)||245;document.getElementById('v91WhiteThresholdVal').textContent=a.whiteThreshold;render();}));
  document.getElementById('v91ArtworkMode').addEventListener('change',()=>document.getElementById('v91ArtworkMode').dispatchEvent(new Event('input')));
  document.getElementById('v91RemoveWhite').addEventListener('change',()=>document.getElementById('v91RemoveWhite').dispatchEvent(new Event('input')));
  document.getElementById('v7SaveProject').onclick=v7DownloadJSON;
  document.getElementById('v7LoadProjectBtn').onclick=()=>document.getElementById('v7LoadProjectFile').click();
  document.getElementById('v7LoadProjectFile').addEventListener('change',e=>{const f=e.target.files?.[0];if(f)v7LoadJSONFile(f);e.target.value='';});
  document.getElementById('v7NewProject').onclick=()=>{
    const base=v7CaptureEditorState();base.txtInput='JERSEY TEXT';
    V7_OBJECTS=[];v91SetTextVisibility(true,false);v92SetArtworkVisibility(true,false);v7NewObject('JERSEY TEXT',base);document.getElementById('v7ProjectName').value='CFB Wordmark Project';render();
  };
  document.getElementById('v7SavePalette').onclick=()=>{
    const name=(document.getElementById('v7PaletteName').value||'Team Palette').trim(),colors=v7UniqueColors(v7PaletteFromCurrent());
    const all=v7GetLocal(V7_PALETTES_KEY);all.push({name,colors});v7SetLocal(V7_PALETTES_KEY,all);v7RenderPalettes();document.getElementById('v7PaletteName').value='';
  };
  document.getElementById('v7SavePreset').onclick=()=>{
    v7CommitActive();const name=(document.getElementById('v7PresetName').value||'Construction Preset').trim();
    const all=v7GetLocal(V7_PRESETS_KEY);all.push({name,state:v7StyleState(v7CaptureEditorState())});v7SetLocal(V7_PRESETS_KEY,all);v7RenderPresets();document.getElementById('v7PresetName').value='';
  };
  document.querySelectorAll('[data-v7-template]').forEach(b=>b.addEventListener('click',()=>v7BuildTemplate(b.dataset.v7Template)));
  document.getElementById('v92CreateMonogram').onclick=()=>v92UpdateMonogram(true);
  document.getElementById('v92ResetMonogram').onclick=v92ResetMonogramControls;
  ['v7MonoA','v7MonoB','v7MonoC','v92MonoFont','v92MonoCount','v92MonoLayout','v92MonoOverlap','v92MonoRotation','v92MonoGap','v92MonoFirstTop','v92AX','v92AY','v92AR','v92AS','v92BX','v92BY','v92BR','v92BS','v92CX','v92CY','v92CR','v92CS'].forEach(id=>{const el=document.getElementById(id);el.addEventListener(el.type==='checkbox'||el.tagName==='SELECT'?'change':'input',()=>{document.getElementById('v92MonoOverlapVal').textContent=document.getElementById('v92MonoOverlap').value+'%';document.getElementById('v92MonoRotationVal').textContent=document.getElementById('v92MonoRotation').value+'°';document.getElementById('v92MonoGapVal').textContent=document.getElementById('v92MonoGap').value;if(V7_OBJECTS.some(o=>o.monogramKey))v92UpdateMonogram();});});
  monoFontSelect.addEventListener('change',async()=>{await ensureFontReady(monoFontSelect.value);if(V7_OBJECTS.some(o=>o.monogramKey))v92UpdateMonogram();});
  v7RenderPalettes();v7RenderPresets();v7RefreshObjectUI();
}


function renderSingle(targetCanvas = null) {
  const canvas = targetCanvas || document.getElementById('txtCanvas');
  const [w, h] = document.getElementById('txtCanvasSize').value.split('x').map(Number);
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, w, h);

  const rawText = document.getElementById('txtInput').value || '';
  const lines = rawText.split('\n').filter((l, i, arr) => l.length || arr.length === 1);
  if (!lines.length || !rawText.trim()) return;

  const fontFamily = document.getElementById('txtFont').value || 'Arial';
  let fillColor = document.getElementById('txtFillHex').value;
  const strokeOn = document.getElementById('txtStrokeOn').checked;
  let strokeColor = document.getElementById('txtStrokeHex').value;
  const strokeWidth = Number(document.getElementById('txtStrokeWidth').value);
  const outerStrokeOn = document.getElementById('txtOuterStrokeOn').checked;
  let outerStrokeColor = document.getElementById('txtOuterStrokeHex').value;
  const outerStrokeWidth = Number(document.getElementById('txtOuterStrokeWidth').value);
  const lineJoin = document.querySelector('input[name="txtJoin"]:checked').value;
  const stitchOn = document.getElementById('txtStitchOn').checked;
  const stitchSize = Number(document.getElementById('txtStitchSize').value);
  const stitchGap = Number(document.getElementById('txtStitchGap').value);
  const stitchWidth = Number(document.getElementById('txtStitchWidth').value);
  let stitchColor = document.getElementById('txtStitchHex').value;
  const texture = document.getElementById('txtTexture').value;
  const textureStrength = Number(document.getElementById('txtTextureStrength').value);
  const textureScale = Number(document.getElementById('txtTextureScale').value);
  let textureColor = document.getElementById('txtTextureHex').value;
  const italicOn = document.getElementById('txtItalicOn').checked;
  const slantDeg = Number(document.getElementById('txtSlant').value);
  const letterSpacing = Number(document.getElementById('txtLetterSpacing').value);
  const scaleX = Number(document.getElementById('txtScaleX').value) / 100;
  const scaleY = Number(document.getElementById('txtScaleY').value) / 100;
  const lineSpacing = Number(document.getElementById('txtLineSpacing').value) / 100;
  const rotation = Number(document.getElementById('txtRotation').value) * Math.PI / 180;
  const archOn = document.getElementById('txtArchOn').checked;
  const archStrength = archOn ? Number(document.getElementById('txtArch').value) : 0;
  const shadowOn = document.getElementById('txtShadowOn').checked;
  let shadowColor = document.getElementById('txtShadowHex').value;
  const shadowX = Number(document.getElementById('txtShadowX').value);
  const shadowY = Number(document.getElementById('txtShadowY').value);
  const shadowBlur = Number(document.getElementById('txtShadowBlur').value);
  const shadowOpacity = Number(document.getElementById('txtShadowOpacity').value) / 100;
  const productionView=document.getElementById('txtProductionView').checked;
  const insetOn=document.getElementById('txtInsetOn').checked, insetWidth=Number(document.getElementById('txtInsetWidth').value); let insetColor=document.getElementById('txtInsetHex').value;
  const twillLayersOn=document.getElementById('txtTwillLayersOn').checked, twill2Width=Number(document.getElementById('txtTwill2Width').value), twill3Width=Number(document.getElementById('txtTwill3Width').value); let twill2Color=document.getElementById('txtTwill2Hex').value, twill3Color=document.getElementById('txtTwill3Hex').value;
  const extrudeOn=document.getElementById('txtExtrudeOn').checked, extrudeDepth=Number(document.getElementById('txtExtrudeDepth').value), extrudeAngle=Number(document.getElementById('txtExtrudeAngle').value)*Math.PI/180; let extrudeColor=document.getElementById('txtExtrudeHex').value;
  const bevelOn=document.getElementById('txtBevelOn').checked, bevelSize=Number(document.getElementById('txtBevelSize').value), bevelStrength=Number(document.getElementById('txtBevelStrength').value);
  const gradientOn=document.getElementById('txtGradientOn').checked, gradientAngle=Number(document.getElementById('txtGradientAngle').value)*Math.PI/180; let gradientA=document.getElementById('txtGradientAHex').value, gradientB=document.getElementById('txtGradientBHex').value;
  const finish=document.getElementById('txtFinish').value, finishStrength=Number(document.getElementById('txtFinishStrength').value);
  const overlayOpacity=Number(document.getElementById('txtOverlayOpacity').value), overlayScale=Number(document.getElementById('txtOverlayScale').value);
  ACTIVE_KERNING=document.querySelector('input[name="txtKerning"]:checked').value;
  ACTIVE_ARCH_TYPE=document.getElementById('txtArchType').value;
  ACTIVE_LETTER_EDIT={on:document.getElementById('txtLetterEditOn').checked,index:Number(document.getElementById('txtLetterIndex').value)-1,x:Number(document.getElementById('txtLetterX').value),y:Number(document.getElementById('txtLetterY').value),rotate:Number(document.getElementById('txtLetterRotate').value)*Math.PI/180,scale:Number(document.getElementById('txtLetterScale').value)/100,colorOn:document.getElementById('txtLetterColorOn').checked,color:document.getElementById('txtLetterHex').value};
  ACTIVE_WARP={on:document.getElementById('txtWarpOn').checked,type:document.getElementById('txtWarpType').value,strength:Number(document.getElementById('txtWarpStrength').value),cycles:Number(document.getElementById('txtWarpCycles').value)};
  ACTIVE_IMPERFECTION={on:document.getElementById('txtVintageOn').checked,baseline:Number(document.getElementById('txtVintageBaseline').value),rotation:Number(document.getElementById('txtVintageRotation').value),scale:Number(document.getElementById('txtVintageScale').value),tracking:Number(document.getElementById('txtVintageTracking').value),seed:Number(document.getElementById('txtVintageSeed').value)};
  const stitchStudio={style:document.getElementById('txtStitchStyle').value,color:stitchColor,color2:document.getElementById('txtStitch2Hex').value,size:stitchSize,gap:stitchGap,width:stitchWidth,inset:Number(document.getElementById('txtStitchInset').value),irregularity:Number(document.getElementById('txtStitchIrregularity').value),twill:document.getElementById('txtStitchTwillOn').checked};
  const tailOpts={on:document.getElementById('txtTailOn').checked,style:document.getElementById('txtTailStyle').value,color:document.getElementById('txtTailHex').value,length:Number(document.getElementById('txtTailLength').value),width:Number(document.getElementById('txtTailWidth').value),curve:Number(document.getElementById('txtTailCurve').value),y:Number(document.getElementById('txtTailY').value)};
  const patternOpts={on:document.getElementById('txtPatternOn').checked,type:document.getElementById('txtPatternType').value,a:document.getElementById('txtPatternAHex').value,b:document.getElementById('txtPatternBHex').value,opacity:Number(document.getElementById('txtPatternOpacity').value),scale:Number(document.getElementById('txtPatternScale').value),angle:Number(document.getElementById('txtPatternAngle').value)*Math.PI/180,text:document.getElementById('txtPatternText').value};
  const vintageWear=document.getElementById('txtVintageOn').checked?Number(document.getElementById('txtVintageWear').value):0;

  if(productionView){fillColor='#FF0000';strokeColor='#0000FF';outerStrokeColor='#00FF00';stitchColor='#FFFFFF';shadowColor='#808080';textureColor='#FFFF00';insetColor='#00FFFF';twill2Color='#FF00FF';twill3Color='#00FF00';extrudeColor='#FFA500';gradientA='#FF0000';gradientB='#0000FF';}


  const maxOutline = Math.max(strokeOn ? strokeWidth : 0, outerStrokeOn ? outerStrokeWidth : 0, twillLayersOn ? twill3Width : 0);
  const shadowPad = Math.max(shadowOn ? Math.max(Math.abs(shadowX), Math.abs(shadowY)) + shadowBlur * 2 : 0, extrudeOn ? extrudeDepth : 0);
  const slantPad = italicOn ? Math.abs(Math.tan(slantDeg * Math.PI / 180)) * h * 0.25 : 0;
  const padding = Math.max(maxOutline * 2 + shadowPad + slantPad, 24);
  const maxWidth = Math.max(40, w - padding * 2);
  const maxHeight = Math.max(40, h - padding * 2);

  const fontSize = fitFontSize(ctx, lines, fontFamily, maxWidth, maxHeight, letterSpacing, scaleX, scaleY, lineSpacing, archStrength);
  const archAmount = fontSize * archStrength / 100 * 1.15;
  ctx.font = `${fontSize}px ${canvasFontFamily(fontFamily)}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineJoin = lineJoin;
  ctx.miterLimit = 4;

  const lineHeight = fontSize * lineSpacing;
  const totalHeight = lineHeight * lines.length;
  const startY = -totalHeight / 2 + lineHeight / 2;

  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.rotate(rotation);
  if (italicOn) ctx.transform(1, 0, Math.tan(-slantDeg * Math.PI / 180), 1, 0, 0);
  ctx.scale(scaleX, scaleY);

  function drawLayer(mode, color, width, dashed) {
    if (mode === 'stroke') {
      ctx.lineWidth = width;
      ctx.strokeStyle = color;
      if (dashed) ctx.setLineDash(dashed);
      else ctx.setLineDash([]);
    } else {
      ctx.fillStyle = color;
      ctx.setLineDash([]);
    }
    lines.forEach((line, i) => drawSpacedText(ctx, line, 0, startY + i * lineHeight, letterSpacing, mode, archAmount));
  }

  const primaryTextWidth=Math.max(...lines.map(line=>measureSpacedText(ctx,line,letterSpacing)),1);
  if(tailOpts.on) drawScriptTail(ctx,tailOpts,primaryTextWidth,startY+(lines.length-1)*lineHeight,fontSize);

  // Construction passes behind the normal outline stack.
  if (extrudeOn) {
    ctx.save();
    for(let d=extrudeDepth;d>=1;d--){ctx.save();ctx.translate(Math.cos(extrudeAngle)*d/scaleX,Math.sin(extrudeAngle)*d/scaleY);drawLayer('fill',extrudeColor,0,null);if(strokeOn)drawLayer('stroke',extrudeColor,strokeWidth,null);ctx.restore();}
    ctx.restore();
  }
  if(twillLayersOn){drawLayer('stroke',twill3Color,twill3Width,null);drawLayer('stroke',twill2Color,twill2Width,null);}
  if(twillLayersOn && stitchOn && stitchStudio.twill){
    const s3={...stitchStudio,width:Math.max(1,stitchStudio.width*.75),inset:(twill3Width-twill2Width)*.16};
    drawAdvancedStitch(ctx,lines,startY,lineHeight,letterSpacing,archAmount,s3,scaleX,scaleY);
  }

  // Shadow pass: rendered behind all keylines, strokes, and fill.
  if (shadowOn) {
    ctx.save();
    ctx.translate(shadowX / scaleX, shadowY / scaleY);
    ctx.shadowColor = hexToRgba(shadowColor, shadowOpacity);
    ctx.shadowBlur = shadowBlur;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    const shadowPaint = hexToRgba(shadowColor, shadowOpacity);
    if (outerStrokeOn) drawLayer('stroke', shadowPaint, outerStrokeWidth, null);
    else if (strokeOn) drawLayer('stroke', shadowPaint, strokeWidth, null);
    drawLayer('fill', shadowPaint, 0, null);
    ctx.restore();
  }

  // Outside keyline first, then primary outline, then fill.
  if (outerStrokeOn) drawLayer('stroke', outerStrokeColor, outerStrokeWidth, null);

  if (strokeOn) {
    // Always preserve the solid outline. Stitching is now a seam drawn over it, not a replacement for it.
    drawLayer('stroke', strokeColor, strokeWidth, null);
    if (stitchOn) drawAdvancedStitch(ctx,lines,startY,lineHeight,letterSpacing,archAmount,stitchStudio,scaleX,scaleY);
  }

  let fillPaint=fillColor;
  if(gradientOn){const len=Math.max(w,h),dx=Math.cos(gradientAngle)*len/2,dy=Math.sin(gradientAngle)*len/2;const g=ctx.createLinearGradient(-dx,-dy,dx,dy);g.addColorStop(0,gradientA);g.addColorStop(1,gradientB);fillPaint=g;}
  drawLayer('fill', fillPaint, 0, null);
  ctx.restore();

  const drawFillMask=(maskCtx)=>{maskCtx.save();maskCtx.translate(w/2,h/2);maskCtx.rotate(rotation);if(italicOn)maskCtx.transform(1,0,Math.tan(-slantDeg*Math.PI/180),1,0,0);maskCtx.scale(scaleX,scaleY);maskCtx.font=`${fontSize}px ${fontFamily}`;maskCtx.textAlign='center';maskCtx.textBaseline='middle';maskCtx.fillStyle='#fff';lines.forEach((line,i)=>drawSpacedText(maskCtx,line,0,startY+i*lineHeight,letterSpacing,'fill',archAmount));maskCtx.restore();};
  const effectPasses={
    texture:()=>applyTextureOverlay(ctx,w,h,texture,textureStrength,textureScale,textureColor,drawFillMask),
    pattern:()=>applyGeneratedPattern(ctx,w,h,patternOpts,drawFillMask),
    inset:()=>{if(insetOn)applyMaskedLayer(ctx,w,h,drawFillMask,l=>{l.save();l.translate(w/2,h/2);l.rotate(rotation);if(italicOn)l.transform(1,0,Math.tan(-slantDeg*Math.PI/180),1,0,0);l.scale(scaleX,scaleY);l.font=`${fontSize}px ${canvasFontFamily(fontFamily)}`;l.textAlign='center';l.textBaseline='middle';l.lineJoin=lineJoin;l.lineWidth=insetWidth*2;l.strokeStyle=insetColor;lines.forEach((line,i)=>drawSpacedText(l,line,0,startY+i*lineHeight,letterSpacing,'stroke',archAmount));l.restore();});},
    bevel:()=>{if(bevelOn)applyBevel(ctx,w,h,bevelSize,bevelStrength,drawFillMask);},
    finish:()=>applyFinishOverlay(ctx,w,h,finish,finishStrength,drawFillMask),
    overlay:()=>applyCustomOverlay(ctx,w,h,overlayOpacity,overlayScale,drawFillMask)
  };
  EFFECT_LAYER_ORDER.forEach(k=>effectPasses[k]&&effectPasses[k]());
  applyVintageWear(ctx,w,h,vintageWear,ACTIVE_IMPERFECTION.seed,drawFillMask);
}



function applyGeneratedPattern(mainCtx,w,h,opts,drawMask){
  if(!opts.on || opts.opacity<=0) return;
  applyMaskedLayer(mainCtx,w,h,drawMask,l=>{
    const a=opts.opacity/100, sc=Math.max(.2,opts.scale/100), step=Math.max(8,30*sc);
    l.save(); l.translate(w/2,h/2); l.rotate(opts.angle); l.translate(-w/2,-h/2);
    const A=colorAlpha(opts.a,a), B=colorAlpha(opts.b,a*.72);
    const line=(x1,y1,x2,y2,c,lw=2)=>{l.strokeStyle=c;l.lineWidth=lw;l.beginPath();l.moveTo(x1,y1);l.lineTo(x2,y2);l.stroke();};
    if(opts.type==='stripes'){for(let x=-h;x<w+h;x+=step)line(x,-h,x,h*2,A,Math.max(2,step*.36));}
    else if(opts.type==='checker'){for(let y=-step;y<h+step;y+=step)for(let x=-step;x<w+step;x+=step){l.fillStyle=(((x/step|0)+(y/step|0))&1)?A:B;l.fillRect(x,y,step,step);}}
    else if(opts.type==='diamonds'){for(let x=-h;x<w+h;x+=step){line(x,0,x+h,h,A,2*sc);line(x+h,0,x,h,B,2*sc);}}
    else if(opts.type==='dots'){for(let y=0;y<h+step;y+=step)for(let x=0;x<w+step;x+=step){l.fillStyle=A;l.beginPath();l.arc(x+((y/step|0)%2)*step/2,y,step*.14,0,Math.PI*2);l.fill();}}
    else if(opts.type==='stars'){const r=step*.24;for(let y=0;y<h+step;y+=step)for(let x=0;x<w+step;x+=step){l.fillStyle=A;l.beginPath();for(let k=0;k<10;k++){const aa=-Math.PI/2+k*Math.PI/5,rr=k%2?r*.42:r,xx=x+Math.cos(aa)*rr,yy=y+Math.sin(aa)*rr;k?l.lineTo(xx,yy):l.moveTo(xx,yy)}l.closePath();l.fill();}}
    else if(opts.type==='hex'){const r=step*.34,dx=r*1.73,dy=r*1.5;for(let row=0,y=0;y<h+r;row++,y+=dy)for(let x=(row%2)*dx/2;x<w+r;x+=dx){l.strokeStyle=A;l.lineWidth=Math.max(1,2*sc);l.beginPath();for(let k=0;k<6;k++){const aa=Math.PI/3*k,xx=x+r*Math.cos(aa),yy=y+r*Math.sin(aa);k?l.lineTo(xx,yy):l.moveTo(xx,yy)}l.closePath();l.stroke();}}
    else if(opts.type==='houndstooth'){const q=step*.55;for(let y=0;y<h+q;y+=q)for(let x=0;x<w+q;x+=q){if(((x/q|0)+(y/q|0))%2===0){l.fillStyle=A;l.fillRect(x,y,q*.55,q*.55);l.beginPath();l.moveTo(x+q*.55,y);l.lineTo(x+q,y+q*.45);l.lineTo(x+q*.55,y+q*.45);l.closePath();l.fill();}}}
    else if(opts.type==='plaid'){for(let x=0;x<w;x+=step){l.fillStyle=A;l.fillRect(x,0,step*.25,h)}for(let y=0;y<h;y+=step){l.fillStyle=B;l.fillRect(0,y,w,step*.25)}}
    else if(opts.type==='argyle'){for(let y=0;y<h+step;y+=step)for(let x=0;x<w+step;x+=step){l.strokeStyle=((x/step|0)+(y/step|0))%2?A:B;l.lineWidth=2*sc;l.beginPath();l.moveTo(x,y+step/2);l.lineTo(x+step/2,y);l.lineTo(x+step,y+step/2);l.lineTo(x+step/2,y+step);l.closePath();l.stroke();}}
    else if(opts.type==='waves'){for(let base=0;base<h+step;base+=step){l.strokeStyle=A;l.lineWidth=2*sc;l.beginPath();for(let x=0;x<=w;x+=5*sc){const yy=base+Math.sin(x/(step*.55))*step*.18;x?l.lineTo(x,yy):l.moveTo(x,yy)}l.stroke();}}
    else if(opts.type==='microtext'){l.font=`700 ${Math.max(8,11*sc)}px Arial`;l.fillStyle=A;l.textBaseline='top';const txt=(opts.text||'TEAM').toUpperCase();for(let y=0;y<h+step;y+=step*.65)for(let x=-step;x<w+step;x+=Math.max(40,txt.length*8*sc)){l.fillText(txt,x,y);}}
    l.restore();
  });
}

function applyVintageWear(mainCtx,w,h,amount,seed,drawMask){
  if(amount<=0) return;
  const wear=document.createElement('canvas');wear.width=w;wear.height=h;const c=wear.getContext('2d');
  drawMask(c); c.globalCompositeOperation='destination-out';
  const count=Math.floor((w*h)/Math.max(90,900-(amount*7)));
  for(let i=0;i<count;i++){
    const x=seededNoise(i,1,seed)*w,y=seededNoise(i,2,seed+4)*h;
    const rw=(1+seededNoise(i,3,seed+8)*10)*(amount/45+0.35),rh=(.7+seededNoise(i,4,seed+12)*3)*(amount/55+0.35);
    c.globalAlpha=.25+(amount/100)*.7;c.fillStyle='#000';c.fillRect(x,y,rw,rh);
  }
  mainCtx.save();mainCtx.globalCompositeOperation='destination-out';mainCtx.drawImage(wear,0,0);mainCtx.restore();
}

function drawScriptTail(ctx, opts, textWidth, baseY, fontSize){
  if(!opts.on) return;
  const len=textWidth*(opts.length/100), x0=-textWidth*.44, x1=x0+len, y=baseY+fontSize*(opts.y/100);
  ctx.save();ctx.strokeStyle=opts.color;ctx.lineWidth=opts.width;ctx.lineCap='round';ctx.lineJoin='round';
  const curve=fontSize*(opts.curve/100)*.7;
  const path=(dy=0)=>{
    ctx.beginPath();
    if(opts.style==='straight'){ctx.moveTo(x0,y+dy);ctx.lineTo(x1,y+dy);}
    else if(opts.style==='lightning'){ctx.moveTo(x0,y+dy);ctx.lineTo(x0+len*.42,y+curve*.2+dy);ctx.lineTo(x0+len*.34,y+curve*.58+dy);ctx.lineTo(x1,y-curve*.12+dy);}
    else if(opts.style==='wave'){ctx.moveTo(x0,y+dy);ctx.bezierCurveTo(x0+len*.22,y+curve+dy,x0+len*.34,y-curve+dy,x0+len*.5,y+dy);ctx.bezierCurveTo(x0+len*.68,y+curve+dy,x0+len*.82,y-curve*.45+dy,x1,y+dy);}
    else if(opts.style==='return'){ctx.moveTo(x0,y+dy);ctx.bezierCurveTo(x0+len*.38,y+curve+dy,x0+len*.82,y+curve*.5+dy,x1,y-curve*.75+dy);}
    else {ctx.moveTo(x0,y+dy);ctx.bezierCurveTo(x0+len*.26,y+curve+dy,x0+len*.72,y+curve+dy,x1,y-curve*.2+dy);}
    ctx.stroke();
  };
  path(0); if(opts.style==='double') path(opts.width*1.8);
  ctx.restore();
}

function stitchDashForStyle(style,len,gap){
  if(style==='zigzag') return [Math.max(1,len*.3),Math.max(1,gap*.25)];
  if(style==='satin') return [Math.max(1,len*.12),Math.max(.8,gap*.16)];
  if(style==='chain') return [Math.max(2,len*.58),Math.max(1,gap*.28)];
  if(style==='cross') return [Math.max(1,len*.34),Math.max(1,gap*.32)];
  if(style==='blanket') return [Math.max(1,len*.18),Math.max(2,gap*.82)];
  if(style==='baseball') return [Math.max(2,len*.7),Math.max(1,gap*.38)];
  if(style==='loose') return [Math.max(2,len*1.25),Math.max(2,gap*1.1)];
  return [len,gap];
}

function drawAdvancedStitch(ctx, lines, startY, lineHeight, letterSpacing, archAmount, opts, scaleX, scaleY){
  const dash=stitchDashForStyle(opts.style,opts.size,opts.gap);
  const pass=(color,offsetX=0,offsetY=0,dashOffset=0,width=opts.width)=>{
    ctx.save();ctx.translate(offsetX/scaleX,offsetY/scaleY);ctx.setLineDash(dash);ctx.lineDashOffset=dashOffset;ctx.lineCap=opts.style==='satin'?'butt':'round';ctx.lineJoin='round';ctx.lineWidth=Math.max(1,width);ctx.strokeStyle=color;
    lines.forEach((line,i)=>drawSpacedText(ctx,line,0,startY+i*lineHeight,letterSpacing,'stroke',archAmount));ctx.restore();
  };
  const irr=(opts.irregularity/100)*Math.max(1,opts.width*2);
  pass(opts.color,opts.inset,0,irr);
  if(opts.style==='double') pass(opts.color2,-opts.inset,Math.max(1,opts.width*2.2),opts.size*.5);
  else if(opts.style==='baseball'){pass(opts.color2,-opts.inset,Math.max(1,opts.width*1.8),opts.size*.55);}
  else if(opts.style==='cross'){pass(opts.color2,-opts.inset,Math.max(1,opts.width*1.1),-opts.size*.45,Math.max(1,opts.width*.7));}
  else if(opts.style==='chain'){pass(opts.color2,opts.inset+opts.width*.65,0,-opts.size*.25,Math.max(1,opts.width*.45));}
  else if(opts.style==='zigzag'){pass(opts.color2,-opts.inset,Math.max(1,opts.width*.8),-opts.size*.2,Math.max(1,opts.width*.55));}
  else if(opts.style==='loose') pass(textStudioShade(opts.color,25),opts.inset+irr,irr*.4,-opts.size*.15,Math.max(.7,opts.width*.42));
}

function renderLayerStackUI(){
  const host=document.getElementById('txtLayerStack'); if(!host) return;
  const names={texture:'Texture',pattern:'Generated pattern',inset:'Inset / inline',bevel:'2D bevel',finish:'Finish',overlay:'Custom overlay'};
  host.innerHTML='';
  [...EFFECT_LAYER_ORDER].reverse().forEach(key=>{
    const row=document.createElement('div');row.className='layer-row';
    row.innerHTML=`<span>${names[key]||key}</span><button type="button" data-dir="up">↑</button><button type="button" data-dir="down">↓</button>`;
    row.querySelector('[data-dir="up"]').onclick=()=>moveEffectLayer(key,1);
    row.querySelector('[data-dir="down"]').onclick=()=>moveEffectLayer(key,-1);
    host.appendChild(row);
  });
}
function moveEffectLayer(key,dir){
  const i=EFFECT_LAYER_ORDER.indexOf(key),j=i+dir;if(i<0||j<0||j>=EFFECT_LAYER_ORDER.length)return;
  [EFFECT_LAYER_ORDER[i],EFFECT_LAYER_ORDER[j]]=[EFFECT_LAYER_ORDER[j],EFFECT_LAYER_ORDER[i]];
  try{localStorage.setItem('jerseyEffectLayerOrderV1',JSON.stringify(EFFECT_LAYER_ORDER));}catch{} renderLayerStackUI();render();
}
function setupEffectLayerStack(){
  try{const a=JSON.parse(localStorage.getItem('jerseyEffectLayerOrderV1')||'null');if(Array.isArray(a)&&a.length===6)EFFECT_LAYER_ORDER=a;}catch{}
  renderLayerStackUI();
  document.getElementById('txtLayerReset').addEventListener('click',()=>{EFFECT_LAYER_ORDER=['texture','pattern','inset','bevel','finish','overlay'];try{localStorage.removeItem('jerseyEffectLayerOrderV1');}catch{} renderLayerStackUI();render();});
}


const SAVED_COLORS_KEY = 'jerseyWordmarkSavedColorsV1';
let activeColorHexId = 'txtFillHex';
let activeColorPickerId = 'txtFillColor';

function normalizeSavedHex(v) {
  v = String(v || '').trim().toUpperCase();
  if (!v.startsWith('#')) v = '#' + v;
  if (/^#[0-9A-F]{6}$/.test(v)) return v;
  if (/^#[0-9A-F]{3}$/.test(v)) return '#' + v.slice(1).split('').map(c => c + c).join('');
  return null;
}
function getSavedColors() {
  try {
    const arr = JSON.parse(localStorage.getItem(SAVED_COLORS_KEY) || '[]');
    return Array.isArray(arr) ? arr : [];
  } catch { return []; }
}
function setSavedColors(arr) {
  localStorage.setItem(SAVED_COLORS_KEY, JSON.stringify(arr));
  renderSavedColors();
}
function rememberActiveColor(colorId, hexId) {
  activeColorPickerId = colorId;
  activeColorHexId = hexId;
}
function applySavedColor(hex, colorId = activeColorPickerId, hexId = activeColorHexId) {
  const hexInput = document.getElementById(hexId);
  const colorInput = document.getElementById(colorId);
  if (hexInput) {
    hexInput.value = hex;
    hexInput.dispatchEvent(new Event('input', { bubbles: true }));
  }
  if (colorInput) colorInput.value = hex.toLowerCase();
  rememberActiveColor(colorId, hexId);
  render();
}
function buildSavedColorChip(hex, colorId, hexId) {
  const chip = document.createElement('button');
  chip.type = 'button';
  chip.className = 'saved-color-chip';
  chip.style.background = hex;
  chip.dataset.hex = hex;
  chip.title = `Apply ${hex}`;
  chip.setAttribute('aria-label', `Apply saved color ${hex}`);
  chip.addEventListener('click', () => applySavedColor(hex, colorId, hexId));
  chip.addEventListener('contextmenu', e => {
    e.preventDefault();
    setSavedColors(getSavedColors().filter(c => c !== hex));
  });
  return chip;
}
function renderSavedColors() {
  const colors = getSavedColors();
  const main = document.getElementById('savedColorsPalette');
  if (main) {
    main.innerHTML = '';
    colors.forEach(hex => main.appendChild(buildSavedColorChip(hex, activeColorPickerId, activeColorHexId)));
  }
  document.querySelectorAll('.saved-colors-inline').forEach(wrap => {
    wrap.innerHTML = '';
    if (!colors.length) return;
    const label = document.createElement('span');
    label.className = 'saved-colors-inline-label';
    label.textContent = 'Saved colors';
    wrap.appendChild(label);
    colors.forEach(hex => wrap.appendChild(buildSavedColorChip(hex, wrap.dataset.colorId, wrap.dataset.hexId)));
  });
}
function ensureInlineSavedPalette(colorId, hexId) {
  const colorInput = document.getElementById(colorId);
  const hexInput = document.getElementById(hexId);
  if (!colorInput || !hexInput) return;
  const pair = colorInput.closest('.color-pair') || hexInput.closest('.color-pair');
  if (!pair) return;
  const parent = pair.parentElement;
  if (parent.querySelector(`.saved-colors-inline[data-color-id="${colorId}"]`)) return;
  const palette = document.createElement('div');
  palette.className = 'saved-colors-inline';
  palette.dataset.colorId = colorId;
  palette.dataset.hexId = hexId;
  pair.insertAdjacentElement('afterend', palette);
}
function setupSavedColors() {
  const input = document.getElementById('savedColorInput');
  const saveBtn = document.getElementById('saveColorBtn');
  const clearBtn = document.getElementById('clearSavedColorsBtn');
  if (!input || !saveBtn || !clearBtn) return;

  saveBtn.addEventListener('click', () => {
    const hex = normalizeSavedHex(input.value);
    if (!hex) return;
    const arr = getSavedColors();
    if (!arr.includes(hex)) arr.push(hex);
    input.value = hex;
    setSavedColors(arr);
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') saveBtn.click();
  });
  clearBtn.addEventListener('click', () => {
    localStorage.removeItem(SAVED_COLORS_KEY);
    renderSavedColors();
  });
  renderSavedColors();
}

function linkColorPair(colorId, hexId) {
  const colorInput = document.getElementById(colorId);
  const hexInput = document.getElementById(hexId);
  ensureInlineSavedPalette(colorId, hexId);
  const markActive = () => rememberActiveColor(colorId, hexId);
  colorInput.addEventListener('focus', markActive);
  colorInput.addEventListener('click', markActive);
  hexInput.addEventListener('focus', markActive);
  hexInput.addEventListener('click', markActive);
  colorInput.addEventListener('input', () => {
    markActive();
    hexInput.value = colorInput.value.toUpperCase();
    render();
  });
  hexInput.addEventListener('change', () => {
    markActive();
    let v = hexInput.value.trim();
    if (!v.startsWith('#')) v = '#' + v;
    if (/^#[0-9A-Fa-f]{6}$/.test(v)) {
      hexInput.value = v.toUpperCase();
      colorInput.value = v;
      render();
    }
  });
}

const BUNDLED_FONTS = [
  'Anton','BebasNeue','OswaldBold','RussoOne','Bangers','PermanentMarker',
  'CFB_InterDisplayBlack','CFB_RobotoCondensedBold','CFB_RobotoSlabBold','CFB_OpenSansCondBold',
  'CFB_LatoBlack','CFB_CabinBold','CFB_LiberationSansNarrowBold','CFB_DejaVuSansCondBold',
  'CFB_DejaVuSerifCondBold','CFB_GoBold','CFB_ClearSansBold','CFB_ArimoBold','CFB_TinosBold',
  'CFB_PTSansNarrowBold','CFB_CaladeaBold','CFB_NotoSansBlack','CFB_NotoSansCondBlack','CFB_LobsterTwoBold',
  'USR_001','USR_002','USR_003','USR_004','USR_005','USR_006','USR_007','USR_008','USR_009','USR_010','USR_011','USR_012','USR_013','USR_014','USR_015','USR_016','USR_017','USR_018','USR_019','USR_020','USR_021','USR_022','USR_023','USR_024','USR_025','USR_026','USR_027','USR_028','USR_029','USR_030','USR_031','USR_032','USR_033','USR_034','USR_035','USR_036','USR_037','USR_038','USR_039','USR_040','USR_041','USR_042','USR_043','USR_044','USR_045','USR_046','USR_047','USR_048','USR_049','USR_050','USR_051','USR_052','USR_053','USR_054','USR_055','USR_056','USR_057','USR_058','USR_059','USR_060','USR_061','USR_062','USR_063','USR_064','USR_065','USR_066','USR_067','USR_068','USR_069','USR_070','USR_071','USR_072','USR_073','USR_074','USR_075','USR_076','USR_077','USR_078','USR_079','USR_080','USR_081'];

function canvasFontFamily(family){
  // System fallback values intentionally contain commas. Embedded/custom faces are
  // quoted so Canvas parses their private family names exactly.
  if (String(family).includes(',')) return family;
  return `"${String(family).replace(/["\\]/g, '\\$&')}"`;
}

const FONT_LOAD_STATE = new Map();
async function ensureFontReady(family){
  if (!family || String(family).includes(',')) return true;
  if (!document.fonts || !document.fonts.load) return true;
  if (FONT_LOAD_STATE.get(family) === 'ready') return true;
  try {
    FONT_LOAD_STATE.set(family,'loading');
    await document.fonts.load(`400 100px ${canvasFontFamily(family)}`, 'CFB');
    await document.fonts.ready;
    const ok = document.fonts.check(`400 100px ${canvasFontFamily(family)}`, 'CFB');
    FONT_LOAD_STATE.set(family, ok ? 'ready' : 'failed');
    return ok;
  } catch (e) {
    FONT_LOAD_STATE.set(family,'failed');
    return false;
  }
}

async function preloadBundledFonts(){
  const results = await Promise.all(BUNDLED_FONTS.map(async family => [family, await ensureFontReady(family)]));
  const failed = results.filter(([,ok]) => !ok).map(([family]) => family);
  if (failed.length) setFontStatus(`Font loader recovered ${BUNDLED_FONTS.length-failed.length}/${BUNDLED_FONTS.length} stock faces.`, true);
  return failed;
}

let customFontCounter = 0;

function setFontStatus(msg, isError) {
  const el = document.getElementById('txtFontStatus');
  el.textContent = msg || '';
  el.style.color = isError ? '#e08080' : 'var(--accent)';
  if (msg) setTimeout(() => { if (el.textContent === msg) el.textContent = ''; }, 4000);
}

function addCustomFontChip(displayName, family) {
  const list = document.getElementById('customFontList');
  const chip = document.createElement('div');
  chip.className = 'font-chip';

  const label = document.createElement('span');
  label.className = 'font-chip-name';
  label.textContent = displayName;
  chip.appendChild(label);

  const removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.className = 'font-chip-remove';
  removeBtn.textContent = '✕';
  removeBtn.title = `Remove ${displayName}`;
  removeBtn.addEventListener('click', () => {
    document.fonts.forEach(f => { if (f.family === family) document.fonts.delete(f); });
    const select = document.getElementById('txtFont');
    const opt = Array.from(select.options).find(o => o.value === family);
    const wasSelected = opt && select.value === family;
    if (opt) opt.remove();
    chip.remove();
    if (wasSelected) {
      select.value = 'Anton';
      render();
    }
  });
  chip.appendChild(removeBtn);

  list.appendChild(chip);
}

function handleFontUpload(fileList) {
  Array.from(fileList).forEach(file => {
    const displayName = file.name.replace(/\.[^/.]+$/, '');
    const reader = new FileReader();
    reader.onerror = () => setFontStatus(`Couldn't read ${file.name}`, true);
    reader.onload = (e) => {
      customFontCounter += 1;
      const family = `CustomFont${customFontCounter}`;
      let fontFace;
      try {
        fontFace = new FontFace(family, e.target.result);
      } catch (err) {
        setFontStatus(`Couldn't load ${file.name}`, true);
        return;
      }
      fontFace.load().then(loadedFace => {
        document.fonts.add(loadedFace);
        FONT_LOAD_STATE.set(family,'ready');
        const option = document.createElement('option');
        option.value = family;
        option.textContent = `${displayName} (uploaded)`;
        const select = document.getElementById('txtFont');
        select.appendChild(option);
        select.value = family;
        addCustomFontChip(displayName, family);
        setFontStatus(`Added "${displayName}"`, false);
        render();
      }).catch(() => {
        setFontStatus(`Couldn't load ${file.name} — is it a valid font file?`, true);
      });
    };
    reader.readAsArrayBuffer(file);
  });
}

const V9_AUTOSAVE_KEY='jerseyTextEditorV9Autosave';
let V9_UNDO=[],V9_REDO=[],V9_LAST=null,V9_HISTORY_TIMER=0,V9_RESTORING=false;
function v9Snapshot(){return v7CaptureEditorState();}
function v9ApplySnapshot(s){if(!s)return;V9_RESTORING=true;v7ApplyEditorState(s);const active=v7ActiveObject();if(active)active.state=safeClone(s);render();V9_RESTORING=false;v9UpdateUI();}
function v9UpdateHistoryButtons(){document.getElementById('v9UndoBtn').disabled=!V9_UNDO.length;document.getElementById('v9RedoBtn').disabled=!V9_REDO.length;}
function v9Record(){if(V9_RESTORING)return;clearTimeout(V9_HISTORY_TIMER);V9_HISTORY_TIMER=setTimeout(()=>{const now=v9Snapshot(),json=JSON.stringify(now);if(V9_LAST&&json!==JSON.stringify(V9_LAST)){V9_UNDO.push(V9_LAST);if(V9_UNDO.length>60)V9_UNDO.shift();V9_REDO=[];}V9_LAST=safeClone(now);try{localStorage.setItem(V9_AUTOSAVE_KEY,json);const s=document.getElementById('v9SaveStatus');s.textContent='SAVED';setTimeout(()=>s.textContent='AUTOSAVE ON',900);}catch(e){}v9UpdateHistoryButtons();v9UpdateUI();},180);}
function v9Jump(id,tab='designTab'){const btn=document.querySelector(`.tab-btn[data-tab="${tab}"]`);if(btn)btn.click();setTimeout(()=>document.getElementById(id)?.scrollIntoView({behavior:'smooth',block:'center'}),50);}
function v9UpdateUI(){const host=document.getElementById('v9ActiveStrip');if(!host)return;const defs=[['Fill','txtFillColor','designTab',true],['Outline','txtStrokeOn','designTab',document.getElementById('txtStrokeOn')?.checked],['Keyline','txtOuterStrokeOn','designTab',document.getElementById('txtOuterStrokeOn')?.checked],['Shadow','txtShadowOn','designTab',document.getElementById('txtShadowOn')?.checked],['Stitch','txtStitchOn','designTab',document.getElementById('txtStitchOn')?.checked],['Texture','txtTexture','designTab',document.getElementById('txtTexture')?.value!=='none'],['Twill','txtTwillLayersOn','constructionTab',document.getElementById('txtTwillLayersOn')?.checked],['Extrude','txtExtrudeOn','constructionTab',document.getElementById('txtExtrudeOn')?.checked],['Bevel','txtBevelOn','constructionTab',document.getElementById('txtBevelOn')?.checked],['Gradient','txtGradientOn','constructionTab',document.getElementById('txtGradientOn')?.checked],['Warp','txtWarpOn','constructionTab',document.getElementById('txtWarpOn')?.checked],['Pattern','txtPatternOn','constructionTab',document.getElementById('txtPatternOn')?.checked],['Vintage','txtVintageOn','constructionTab',document.getElementById('txtVintageOn')?.checked]];host.innerHTML='';defs.forEach(([label,id,tab,on])=>{if(!on&&label!=='Fill')return;const b=document.createElement('button');b.type='button';b.className='v9-chip'+(on?' on':'');b.textContent=label;b.onclick=()=>{if(tab!=='designTab'&&document.body.classList.contains('v9-simple'))v9SetMode(false);v9Jump(id,tab)};host.appendChild(b);});}
function v9SetMode(simple){document.body.classList.toggle('v9-simple',simple);document.getElementById('v9SimpleBtn').classList.toggle('active',simple);document.getElementById('v9AdvancedBtn').classList.toggle('active',!simple);localStorage.setItem('jerseyV9Mode',simple?'simple':'advanced');if(simple&&!document.getElementById('designTab').classList.contains('active'))document.querySelector('[data-tab="designTab"]').click();}
function v9BuildAccordions(){document.querySelectorAll('#constructionTab .construction-grid>.fieldblock').forEach((block,i)=>{const label=block.querySelector('.field-label')?.textContent.trim()||`Construction ${i+1}`;const d=document.createElement('details');d.className='v9-section';if(i<2)d.open=true;const s=document.createElement('summary');s.textContent=label;block.parentNode.insertBefore(d,block);d.append(s,block);});}
function setupV9(){v9BuildAccordions();const simple=localStorage.getItem('jerseyV9Mode')!=='advanced';v9SetMode(simple);document.getElementById('v9SimpleBtn').onclick=()=>v9SetMode(true);document.getElementById('v9AdvancedBtn').onclick=()=>v9SetMode(false);document.getElementById('v9UndoBtn').onclick=()=>{if(!V9_UNDO.length)return;V9_REDO.push(v9Snapshot());const s=V9_UNDO.pop();V9_LAST=safeClone(s);v9ApplySnapshot(s);v9UpdateHistoryButtons();};document.getElementById('v9RedoBtn').onclick=()=>{if(!V9_REDO.length)return;V9_UNDO.push(v9Snapshot());const s=V9_REDO.pop();V9_LAST=safeClone(s);v9ApplySnapshot(s);v9UpdateHistoryButtons();};document.querySelectorAll('#designTab input,#designTab select,#designTab textarea,#constructionTab input,#constructionTab select,#constructionTab textarea').forEach(el=>{if(el.type!=='file')el.addEventListener(el.type==='range'?'change':'input',v9Record);el.addEventListener('change',v9Record);});const saved=localStorage.getItem(V9_AUTOSAVE_KEY);if(saved){try{const s=JSON.parse(saved);v9ApplySnapshot(s);document.getElementById('v9SaveStatus').textContent='AUTOSAVE RESTORED';}catch(e){}}V9_LAST=safeClone(v9Snapshot());v9UpdateUI();}

function init() {
  const liveText=document.getElementById('txtInput');
  if(liveText){
    let liveRAF=0;
    const paintLiveText=()=>{
      if(liveRAF) cancelAnimationFrame(liveRAF);
      liveRAF=requestAnimationFrame(()=>{
        liveRAF=0;
        const obj=v7ActiveObject();
        if(obj && !obj.locked){
          if(!obj.state) obj.state=v7CaptureEditorState();
          obj.state.txtInput=liveText.value;
          const first=(liveText.value||'').trim().split('\n')[0];
          if(first) obj.name=first.slice(0,28);
        }
        render();
      });
    };
    liveText.addEventListener('input',paintLiveText,{passive:true});
    liveText.addEventListener('change',paintLiveText,{passive:true});
    liveText.addEventListener('keyup',paintLiveText,{passive:true});
    liveText.addEventListener('compositionend',paintLiveText,{passive:true});
  }

  const ids = [
    'txtInput', 'txtFont', 'txtStrokeOn', 'txtStrokeWidth', 'txtStitchOn', 'txtStitchSize', 'txtStitchGap', 'txtStitchWidth', 'txtTexture', 'txtTextureStrength', 'txtTextureScale', 'txtCanvasSize',
    'txtItalicOn', 'txtSlant', 'txtLetterSpacing', 'txtScaleX', 'txtScaleY', 'txtLineSpacing', 'txtRotation', 'txtArchOn', 'txtArch',
    'txtOuterStrokeOn', 'txtOuterStrokeWidth', 'txtShadowOn', 'txtShadowX', 'txtShadowY', 'txtShadowBlur', 'txtShadowOpacity',
    'txtProductionView','txtInsetOn','txtInsetWidth','txtTwillLayersOn','txtTwill2Width','txtTwill3Width','txtExtrudeOn','txtExtrudeDepth','txtExtrudeAngle','txtBevelOn','txtBevelSize','txtBevelStrength','txtGradientOn','txtGradientAngle','txtFinish','txtFinishStrength','txtOverlayOpacity','txtOverlayScale','txtArchType','txtLetterEditOn','txtLetterIndex','txtLetterX','txtLetterY','txtLetterRotate','txtLetterScale','txtLetterColorOn',
    'txtStitchStyle','txtStitchInset','txtStitchIrregularity','txtStitchTwillOn','txtWarpOn','txtWarpType','txtWarpStrength','txtWarpCycles','txtTailOn','txtTailStyle','txtTailLength','txtTailWidth','txtTailCurve','txtTailY','txtPatternOn','txtPatternType','txtPatternOpacity','txtPatternScale','txtPatternAngle','txtPatternText','txtVintageOn','txtVintageBaseline','txtVintageRotation','txtVintageScale','txtVintageTracking','txtVintageWear','txtVintageSeed'
  ];
  ids.forEach(id => {
    const el = document.getElementById(id);
    const evt = (el.tagName === 'SELECT' || el.type === 'checkbox') ? 'change' : 'input';
    el.addEventListener(evt, render);
  });

  document.getElementById('txtFont').addEventListener('change', async (e) => {
    const family=e.target.value;
    setFontStatus('Loading font…', false);
    const ok=await ensureFontReady(family);
    setFontStatus(ok ? 'Font ready.' : 'That font could not be initialized; using browser fallback.', !ok);
    render();
  });
  document.querySelectorAll('input[name="txtJoin"]').forEach(r => r.addEventListener('change', () => {
    document.getElementById('joinRoundLabel').classList.toggle('active', document.querySelector('input[name=txtJoin][value=round]').checked);
    document.getElementById('joinMiterLabel').classList.toggle('active', document.querySelector('input[name=txtJoin][value=miter]').checked);
    render();
  }));

  linkColorPair('txtFillColor', 'txtFillHex');
  linkColorPair('txtStrokeColor', 'txtStrokeHex');
  linkColorPair('txtOuterStrokeColor', 'txtOuterStrokeHex');
  linkColorPair('txtShadowColor', 'txtShadowHex');
  linkColorPair('txtStitchColor', 'txtStitchHex');
  linkColorPair('txtTextureColor','txtTextureHex');
  linkColorPair('txtInsetColor','txtInsetHex');
  linkColorPair('txtTwill2Color','txtTwill2Hex');
  linkColorPair('txtTwill3Color','txtTwill3Hex');
  linkColorPair('txtExtrudeColor','txtExtrudeHex');
  linkColorPair('txtGradientAColor','txtGradientAHex');
  linkColorPair('txtGradientBColor','txtGradientBHex');
  linkColorPair('txtLetterColor','txtLetterHex');
  linkColorPair('txtStitch2Color','txtStitch2Hex');
  linkColorPair('txtTailColor','txtTailHex');
  linkColorPair('txtPatternAColor','txtPatternAHex');
  linkColorPair('txtPatternBColor','txtPatternBHex');
  renderSavedColors();
  setupSavedColors();
  setupEffectLayerStack();

  const valueLinks = [
    ['txtStrokeWidth','txtStrokeWidthVal',''], ['txtStitchSize','txtStitchSizeVal',''], ['txtStitchGap','txtStitchGapVal',''], ['txtStitchWidth','txtStitchWidthVal',''],
    ['txtTextureStrength','txtTextureStrengthVal','%'], ['txtTextureScale','txtTextureScaleVal','%'],
    ['txtSlant','txtSlantVal','°'], ['txtLetterSpacing','txtLetterSpacingVal',''],
    ['txtScaleX','txtScaleXVal','%'], ['txtScaleY','txtScaleYVal','%'],
    ['txtLineSpacing','txtLineSpacingVal','%'], ['txtRotation','txtRotationVal','°'], ['txtArch','txtArchVal',''],
    ['txtOuterStrokeWidth','txtOuterStrokeWidthVal',''], ['txtShadowX','txtShadowXVal',''],
    ['txtShadowY','txtShadowYVal',''], ['txtShadowBlur','txtShadowBlurVal',''],
    ['txtShadowOpacity','txtShadowOpacityVal','%'],
    ['txtInsetWidth','txtInsetWidthVal',''],['txtTwill2Width','txtTwill2WidthVal',''],['txtTwill3Width','txtTwill3WidthVal',''],['txtExtrudeDepth','txtExtrudeDepthVal',''],['txtExtrudeAngle','txtExtrudeAngleVal','°'],['txtBevelSize','txtBevelSizeVal',''],['txtBevelStrength','txtBevelStrengthVal','%'],['txtGradientAngle','txtGradientAngleVal','°'],['txtFinishStrength','txtFinishStrengthVal','%'],['txtOverlayOpacity','txtOverlayOpacityVal','%'],['txtOverlayScale','txtOverlayScaleVal','%'],['txtLetterIndex','txtLetterIndexVal',''],['txtLetterX','txtLetterXVal',''],['txtLetterY','txtLetterYVal',''],['txtLetterRotate','txtLetterRotateVal','°'],['txtLetterScale','txtLetterScaleVal','%'],
    ['txtStitchInset','txtStitchInsetVal',''],['txtStitchIrregularity','txtStitchIrregularityVal','%'],
    ['txtWarpStrength','txtWarpStrengthVal',''],['txtWarpCycles','txtWarpCyclesVal',''],
    ['txtTailLength','txtTailLengthVal','%'],['txtTailWidth','txtTailWidthVal',''],['txtTailCurve','txtTailCurveVal',''],['txtTailY','txtTailYVal',''],
    ['txtPatternOpacity','txtPatternOpacityVal','%'],['txtPatternScale','txtPatternScaleVal','%'],['txtPatternAngle','txtPatternAngleVal','°'],
    ['txtVintageBaseline','txtVintageBaselineVal','%'],['txtVintageRotation','txtVintageRotationVal','°'],['txtVintageScale','txtVintageScaleVal','%'],['txtVintageTracking','txtVintageTrackingVal',''],['txtVintageWear','txtVintageWearVal','%'],['txtVintageSeed','txtVintageSeedVal','']
  ];
  valueLinks.forEach(([inputId, valId, suffix]) => {
    document.getElementById(inputId).addEventListener('input', (e) => {
      document.getElementById(valId).textContent = e.target.value + suffix;
    });
  });

  document.getElementById('txtStitchOn').addEventListener('change', (e) => {
    document.getElementById('txtStitchControls').style.display = e.target.checked ? 'block' : 'none';
  });
  document.getElementById('txtItalicOn').addEventListener('change', (e) => {
    document.getElementById('txtItalicControls').style.display = e.target.checked ? 'flex' : 'none';
  });
  document.getElementById('txtArchOn').addEventListener('change', (e) => {
    document.getElementById('txtArchControls').style.display = e.target.checked ? 'flex' : 'none';
  });
  document.getElementById('txtOuterStrokeOn').addEventListener('change', (e) => {
    document.getElementById('txtOuterStrokeControls').style.display = e.target.checked ? 'block' : 'none';
  });
  document.getElementById('txtShadowOn').addEventListener('change', (e) => {
    document.getElementById('txtShadowControls').style.display = e.target.checked ? 'block' : 'none';
  });

  [['txtInsetOn','txtInsetControls'],['txtTwillLayersOn','txtTwillLayersControls'],['txtExtrudeOn','txtExtrudeControls'],['txtBevelOn','txtBevelControls'],['txtGradientOn','txtGradientControls'],['txtLetterEditOn','txtLetterEditControls'],['txtWarpOn','txtWarpControls'],['txtTailOn','txtTailControls'],['txtPatternOn','txtPatternControls'],['txtVintageOn','txtVintageControls']].forEach(([a,b])=>document.getElementById(a).addEventListener('change',e=>{document.getElementById(b).style.display=e.target.checked?'block':'none';}));
  document.querySelectorAll('input[name="txtKerning"]').forEach(r=>r.addEventListener('change',()=>{document.getElementById('kernFontLabel').classList.toggle('active',document.querySelector('input[name=txtKerning][value=font]').checked);document.getElementById('kernOpticalLabel').classList.toggle('active',document.querySelector('input[name=txtKerning][value=optical]').checked);render();}));
  document.querySelectorAll('.tab-btn').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.tab-btn').forEach(b=>b.classList.toggle('active',b===btn));document.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active',p.id===btn.dataset.tab));}));
  document.getElementById('txtOverlayUpload').addEventListener('change',e=>{const f=e.target.files&&e.target.files[0];if(!f)return;const rd=new FileReader();rd.onload=ev=>{const img=new Image();img.onload=()=>{CUSTOM_OVERLAY_IMAGE=img;render();};img.src=ev.target.result;};rd.readAsDataURL(f);});
  document.getElementById('txtOverlayClear').addEventListener('click',()=>{CUSTOM_OVERLAY_IMAGE=null;document.getElementById('txtOverlayUpload').value='';render();});
  document.getElementById('txtFontTestBtn')?.addEventListener('click', async () => {
    setFontStatus('Testing 105 embedded stock fonts…', false);
    const results=[];
    for(const family of BUNDLED_FONTS) results.push([family,await ensureFontReady(family)]);
    const failed=results.filter(([,ok])=>!ok).map(([f])=>f);
    setFontStatus(failed.length ? `${105-failed.length}/105 stock fonts loaded. Failed: ${failed.join(', ')}` : 'All 105 embedded stock fonts loaded successfully.', !!failed.length);
    render();
  });

  document.getElementById('txtFontUpload').addEventListener('change', (e) => {
    if (e.target.files && e.target.files.length) {
      handleFontUpload(e.target.files);
      e.target.value = '';
    }
  });

  async function exportPngToDevice() {
    const canvas = document.getElementById('txtCanvas');
    if (!canvas) return;
    const blob = await new Promise((resolve, reject) => {
      canvas.toBlob((result) => result ? resolve(result) : reject(new Error('PNG export failed')), 'image/png');
    });
    const safeText = (document.getElementById('txtInput')?.value || 'wordmark')
      .trim().replace(/[^a-z0-9_-]+/gi, '_').replace(/^_+|_+$/g, '').slice(0, 48) || 'wordmark';
    const fileName = `${safeText}.png`;
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
  }

  document.getElementById('txtDownloadBtn').addEventListener('click', exportPngToDevice);

  v7SetupWorkspace();
  setupBakedEffectGrid();
  setupMobileV8();
  setupPreviewViewerV84();
  setupV9();
  render();
  preloadBundledFonts().then(() => {
    // Commit/repaint after the browser has decoded the embedded font binaries.
    const active=v7ActiveObject();
    if(active) v7ApplyEditorState(active.state);
    render();
  }).catch(() => render());
}

init();

