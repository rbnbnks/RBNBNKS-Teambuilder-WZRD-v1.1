# RBNBNKS' TB WZRD V1 — branding update

## Install
1. Unzip this archive.
2. Open chrome://extensions, enable Developer mode, select Load unpacked, and choose the `rbnbnks-tb-wzrd` folder.
3. Click the extension toolbar icon to open the Team Builder editor.
4. Use the top navigation to open **Design Studio** or **Team Builder**.

## Preserved components
- Full original standalone V9.2 wordmark/artwork studio (`studio.html`), including its embedded font assets and existing JavaScript.
- Team Builder Helper v0.76.1 (`editor.html`, `editor.js`, `background.js`, `bridge.js`, `capture.js`, `mask-studio.js`, `toptabs.js`).
- Original masks and Jagtool preview gallery.
- Existing manifest permissions, content scripts, and EA Team Builder site integration.

## Scope and limits
This release integrates both original tools into one installable Chrome extension and provides consistent top navigation. It does not claim to merge the two editing engines or add a new Team Builder injection workflow. Original site-dependent features require a live EA session and have not been end-to-end tested here.

## v0.77.1 fix
Moved the Design Studio JavaScript from an inline script to `studio.js` to comply with Chrome Manifest V3 Content Security Policy. All original functions remain in place. Reload the unpacked extension after updating.
